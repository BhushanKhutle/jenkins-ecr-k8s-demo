const client = require('prom-client');

const collectDefaultMetrics = () => {
  client.collectDefaultMetrics({ prefix: 'cake_' });
};

// Custom HTTP metrics
const httpRequestDuration = new client.Histogram({
  name: 'cake_http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 2, 5],
});

const httpRequestTotal = new client.Counter({
  name: 'cake_http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code'],
});

const activeOrders = new client.Gauge({
  name: 'cake_active_orders',
  help: 'Number of active orders being processed',
});

const orderTotal = new client.Counter({
  name: 'cake_orders_total',
  help: 'Total number of orders placed',
  labelNames: ['status'],
});

const revenueTotal = new client.Counter({
  name: 'cake_revenue_total',
  help: 'Total revenue processed',
});

module.exports = {
  collectDefaultMetrics,
  httpRequestDuration,
  httpRequestTotal,
  activeOrders,
  orderTotal,
  revenueTotal,
};
