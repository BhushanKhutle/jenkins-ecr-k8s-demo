require('dotenv').config();
const { pool } = require('./database');
const bcrypt = require('bcryptjs');

async function seed() {
  const client = await pool.connect();
  try {
    console.log('🌱 Seeding database...');

    // Admin user
    const adminPass = await bcrypt.hash('Admin@123', 12);
    await client.query(`
      INSERT INTO users (name, email, password, role) VALUES
      ('Admin User', 'admin@cakeshop.com', $1, 'admin')
      ON CONFLICT (email) DO NOTHING`, [adminPass]);

    // Customer
    const custPass = await bcrypt.hash('Customer@123', 12);
    await client.query(`
      INSERT INTO users (name, email, password, phone, address) VALUES
      ('Jane Doe', 'customer@cakeshop.com', $1, '+1234567890', '123 Sweet Street, Baker City')
      ON CONFLICT (email) DO NOTHING`, [custPass]);

    // Categories
    await client.query(`
      INSERT INTO categories (name, description) VALUES
      ('Wedding Cakes', 'Elegant cakes for your special day'),
      ('Birthday Cakes', 'Colorful cakes for every celebration'),
      ('Custom Cakes', 'Personalized cakes to your design'),
      ('Cupcakes', 'Delightful mini cakes'),
      ('Cheesecakes', 'Creamy, rich cheesecakes'),
      ('Seasonal', 'Holiday and seasonal specials')
      ON CONFLICT DO NOTHING`);

    const cats = await client.query('SELECT id, name FROM categories');
    const catMap = {};
    cats.rows.forEach(c => catMap[c.name] = c.id);

    // Cakes
    await client.query(`
      INSERT INTO cakes (name, description, price, category_id, flavors, sizes, weight, servings, is_featured, stock, tags) VALUES
      ('Classic Vanilla Dream', 'Light, fluffy vanilla sponge with buttercream frosting', 45.99, $1,
        '["Vanilla","French Vanilla","Madagascar Vanilla"]','["6 inch","8 inch","10 inch"]', 1.2, 8, true, 15,
        '["bestseller","classic","vanilla"]'),
      ('Chocolate Fudge Supreme', 'Rich dark chocolate cake with ganache layers', 52.99, $2,
        '["Dark Chocolate","Milk Chocolate","White Chocolate"]','["6 inch","8 inch","10 inch","12 inch"]', 1.5, 10, true, 12,
        '["chocolate","fudge","rich"]'),
      ('Red Velvet Romance', 'Classic red velvet with cream cheese frosting', 55.99, $3,
        '["Classic Red Velvet","Chocolate Red Velvet"]','["6 inch","8 inch","10 inch"]', 1.3, 8, false, 10,
        '["red-velvet","romantic"]'),
      ('Strawberry Garden', 'Fresh strawberry sponge with strawberry mousse', 48.99, $4,
        '["Strawberry","Mixed Berry","Raspberry"]','["6 inch","8 inch"]', 1.1, 6, true, 8,
        '["fruity","fresh","seasonal"]'),
      ('Lemon Zest Delight', 'Tangy lemon cake with lemon curd filling', 44.99, $5,
        '["Lemon","Lemon-Lime","Orange"]','["6 inch","8 inch"]', 1.0, 6, false, 10,
        '["citrus","refreshing","light"]'),
      ('Royal Wedding Tier', 'Five-tier fondant wedding cake with floral decorations', 299.99, $6,
        '["Vanilla","Chocolate","Red Velvet","Lemon","Fruit"]','["Tier 1","Tier 2","Tier 3","Full 5-Tier"]', 8.0, 80, true, 3,
        '["wedding","luxury","tiered"]'),
      ('Unicorn Fantasy', 'Magical rainbow cake with unicorn toppers', 65.99, $7,
        '["Rainbow","Vanilla","Confetti"]','["6 inch","8 inch","10 inch"]', 1.4, 10, true, 7,
        '["kids","fantasy","colorful"]'),
      ('Classic New York Cheesecake', 'Dense, creamy New York style cheesecake', 38.99, $8,
        '["Original","Blueberry","Strawberry","Oreo"]','["6 inch","8 inch","10 inch"]', 1.0, 8, false, 12,
        '["cheesecake","classic","creamy"]')
    `, [catMap['Birthday Cakes'], catMap['Birthday Cakes'], catMap['Birthday Cakes'],
        catMap['Birthday Cakes'], catMap['Birthday Cakes'], catMap['Wedding Cakes'],
        catMap['Custom Cakes'], catMap['Cheesecakes']]);

    console.log('✅ Seeding complete!');
    console.log('👤 Admin: admin@cakeshop.com / Admin@123');
    console.log('👤 Customer: customer@cakeshop.com / Customer@123');
  } catch (err) {
    console.error('❌ Seed error:', err.message);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
