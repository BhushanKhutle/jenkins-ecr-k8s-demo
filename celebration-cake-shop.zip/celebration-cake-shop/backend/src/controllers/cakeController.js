const { query } = require('../config/database');
const logger = require('../utils/logger');

exports.getAllCakes = async (req, res) => {
  try {
    const { category, search, minPrice, maxPrice, featured, sort = 'created_at', order = 'DESC', page = 1, limit = 12 } = req.query;
    const conditions = ['c.is_available = true'];
    const params = [];
    let idx = 1;

    if (category) { conditions.push(`cat.name ILIKE $${idx++}`); params.push(`%${category}%`); }
    if (search) { conditions.push(`(c.name ILIKE $${idx++} OR c.description ILIKE $${idx-1})`); params.push(`%${search}%`); }
    if (minPrice) { conditions.push(`c.price >= $${idx++}`); params.push(minPrice); }
    if (maxPrice) { conditions.push(`c.price <= $${idx++}`); params.push(maxPrice); }
    if (featured === 'true') { conditions.push('c.is_featured = true'); }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const sortMap = { price_asc: 'c.price ASC', price_desc: 'c.price DESC', rating: 'c.rating DESC', newest: 'c.created_at DESC', name: 'c.name ASC' };
    const sortStr = sortMap[sort] || 'c.created_at DESC';

    const countResult = await query(`SELECT COUNT(*) FROM cakes c LEFT JOIN categories cat ON c.category_id = cat.id ${whereClause}`, params);
    const total = parseInt(countResult.rows[0].count);

    params.push(parseInt(limit), offset);
    const result = await query(
      `SELECT c.*, cat.name as category_name FROM cakes c LEFT JOIN categories cat ON c.category_id = cat.id ${whereClause} ORDER BY ${sortStr} LIMIT $${idx++} OFFSET $${idx++}`,
      params
    );
    res.json({ success: true, data: result.rows, pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) } });
  } catch (err) {
    logger.error('Get cakes error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch cakes' });
  }
};

exports.getCakeById = async (req, res) => {
  try {
    const result = await query(
      'SELECT c.*, cat.name as category_name FROM cakes c LEFT JOIN categories cat ON c.category_id = cat.id WHERE c.id = $1',
      [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ success: false, message: 'Cake not found' });
    const reviews = await query(
      'SELECT r.*, u.name as user_name FROM reviews r LEFT JOIN users u ON r.user_id = u.id WHERE r.cake_id = $1 ORDER BY r.created_at DESC LIMIT 10',
      [req.params.id]
    );
    res.json({ success: true, data: { ...result.rows[0], reviews: reviews.rows } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch cake' });
  }
};

exports.createCake = async (req, res) => {
  try {
    const { name, description, price, category_id, flavors, sizes, weight, servings, preparation_time, stock, tags, ingredients, allergens } = req.body;
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const result = await query(
      `INSERT INTO cakes (name,description,price,category_id,image,flavors,sizes,weight,servings,preparation_time,stock,tags,ingredients,allergens)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [name, description, price, category_id, image,
       JSON.stringify(flavors || []), JSON.stringify(sizes || []),
       weight, servings, preparation_time || 24, stock || 10,
       JSON.stringify(tags || []), ingredients, allergens]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    logger.error('Create cake error:', err);
    res.status(500).json({ success: false, message: 'Failed to create cake' });
  }
};

exports.updateCake = async (req, res) => {
  try {
    const { name, description, price, category_id, flavors, sizes, weight, servings, stock, is_available, is_featured, tags, ingredients, allergens } = req.body;
    const image = req.file ? `/uploads/${req.file.filename}` : undefined;
    const existing = await query('SELECT * FROM cakes WHERE id = $1', [req.params.id]);
    if (!existing.rows[0]) return res.status(404).json({ success: false, message: 'Cake not found' });

    const result = await query(
      `UPDATE cakes SET name=COALESCE($1,name), description=COALESCE($2,description), price=COALESCE($3,price),
       category_id=COALESCE($4,category_id), image=COALESCE($5,image), flavors=COALESCE($6,flavors),
       sizes=COALESCE($7,sizes), weight=COALESCE($8,weight), servings=COALESCE($9,servings),
       stock=COALESCE($10,stock), is_available=COALESCE($11,is_available), is_featured=COALESCE($12,is_featured),
       tags=COALESCE($13,tags), ingredients=COALESCE($14,ingredients), allergens=COALESCE($15,allergens)
       WHERE id=$16 RETURNING *`,
      [name, description, price, category_id, image,
       flavors ? JSON.stringify(flavors) : null, sizes ? JSON.stringify(sizes) : null,
       weight, servings, stock, is_available, is_featured,
       tags ? JSON.stringify(tags) : null, ingredients, allergens, req.params.id]
    );
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update cake' });
  }
};

exports.deleteCake = async (req, res) => {
  try {
    await query('DELETE FROM cakes WHERE id = $1', [req.params.id]);
    res.json({ success: true, message: 'Cake deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete cake' });
  }
};

exports.getFeaturedCakes = async (req, res) => {
  try {
    const result = await query('SELECT c.*, cat.name as category_name FROM cakes c LEFT JOIN categories cat ON c.category_id = cat.id WHERE c.is_featured = true AND c.is_available = true ORDER BY c.rating DESC LIMIT 8');
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch featured cakes' });
  }
};

exports.getCategories = async (req, res) => {
  try {
    const result = await query('SELECT c.*, COUNT(cakes.id) as cake_count FROM categories c LEFT JOIN cakes ON c.id = cakes.category_id AND cakes.is_available = true GROUP BY c.id ORDER BY c.name');
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch categories' });
  }
};
