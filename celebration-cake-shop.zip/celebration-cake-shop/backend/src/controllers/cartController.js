const { query } = require('../config/database');

exports.getCart = async (req, res) => {
  try {
    const result = await query(
      `SELECT c.*, cakes.name, cakes.price, cakes.image, cakes.is_available
       FROM cart c JOIN cakes ON c.cake_id = cakes.id WHERE c.user_id = $1`,
      [req.user.id]
    );
    const total = result.rows.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    res.json({ success: true, data: { items: result.rows, total } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch cart' });
  }
};

exports.addToCart = async (req, res) => {
  try {
    const { cake_id, quantity = 1, size, flavor, customization } = req.body;
    const cake = await query('SELECT id FROM cakes WHERE id = $1 AND is_available = true', [cake_id]);
    if (!cake.rows[0]) return res.status(404).json({ success: false, message: 'Cake not available' });
    await query(
      `INSERT INTO cart (user_id, cake_id, quantity, size, flavor, customization)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (user_id, cake_id, size, flavor) DO UPDATE SET quantity = cart.quantity + $3`,
      [req.user.id, cake_id, quantity, size || 'default', flavor || 'default', customization]
    );
    res.json({ success: true, message: 'Added to cart' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to add to cart' });
  }
};

exports.updateCartItem = async (req, res) => {
  try {
    const { quantity } = req.body;
    if (quantity < 1) return exports.removeFromCart(req, res);
    await query('UPDATE cart SET quantity = $1 WHERE id = $2 AND user_id = $3', [quantity, req.params.id, req.user.id]);
    res.json({ success: true, message: 'Cart updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update cart' });
  }
};

exports.removeFromCart = async (req, res) => {
  try {
    await query('DELETE FROM cart WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    res.json({ success: true, message: 'Removed from cart' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to remove item' });
  }
};

exports.clearCart = async (req, res) => {
  try {
    await query('DELETE FROM cart WHERE user_id = $1', [req.user.id]);
    res.json({ success: true, message: 'Cart cleared' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to clear cart' });
  }
};
