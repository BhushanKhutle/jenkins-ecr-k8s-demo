const { query } = require('../config/database');

exports.getWishlist = async (req, res) => {
  try {
    const result = await query(
      `SELECT w.*, c.name, c.price, c.image, c.is_available, c.rating
       FROM wishlist w JOIN cakes c ON w.cake_id = c.id WHERE w.user_id = $1 ORDER BY w.created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch wishlist' });
  }
};

exports.toggleWishlist = async (req, res) => {
  try {
    const { cake_id } = req.body;
    const exists = await query('SELECT id FROM wishlist WHERE user_id = $1 AND cake_id = $2', [req.user.id, cake_id]);
    if (exists.rows[0]) {
      await query('DELETE FROM wishlist WHERE user_id = $1 AND cake_id = $2', [req.user.id, cake_id]);
      res.json({ success: true, message: 'Removed from wishlist', wishlisted: false });
    } else {
      await query('INSERT INTO wishlist (user_id, cake_id) VALUES ($1, $2)', [req.user.id, cake_id]);
      res.json({ success: true, message: 'Added to wishlist', wishlisted: true });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update wishlist' });
  }
};
