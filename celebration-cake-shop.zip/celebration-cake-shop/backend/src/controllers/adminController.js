const { query } = require('../config/database');

const getDashboard = async (req, res, next) => {
  try {
    const [ordersRes, revenueRes, usersRes, cakesRes, recentRes, statusRes] = await Promise.all([
      query(`SELECT COUNT(*) AS total,
               SUM(CASE WHEN status NOT IN ('delivered','cancelled') THEN 1 ELSE 0 END) AS active,
               SUM(CASE WHEN DATE(created_at) = CURRENT_DATE THEN 1 ELSE 0 END) AS today
             FROM orders`),
      query(`SELECT COALESCE(SUM(total_amount),0) AS total,
               COALESCE(SUM(CASE WHEN DATE(created_at) = CURRENT_DATE THEN total_amount END),0) AS today,
               COALESCE(SUM(CASE WHEN created_at >= NOW()-INTERVAL '30 days' THEN total_amount END),0) AS month
             FROM orders WHERE payment_status = 'paid'`),
      query(`SELECT COUNT(*) AS total,
               SUM(CASE WHEN DATE(created_at) = CURRENT_DATE THEN 1 ELSE 0 END) AS today
             FROM users WHERE role = 'customer'`),
      query(`SELECT COUNT(*) AS total, SUM(CASE WHEN is_available THEN 1 ELSE 0 END) AS available FROM cakes`),
      query(`SELECT o.id, o.order_number, o.total_amount, o.status, o.created_at,
                    u.first_name, u.last_name, u.email
             FROM orders o JOIN users u ON u.id = o.user_id
             ORDER BY o.created_at DESC LIMIT 10`),
      query(`SELECT status, COUNT(*) AS count FROM orders GROUP BY status`),
    ]);

    const revenueByDay = await query(
      `SELECT DATE(created_at) AS date, COALESCE(SUM(total_amount),0) AS revenue, COUNT(*) AS orders
       FROM orders WHERE created_at >= NOW()-INTERVAL '30 days' AND payment_status='paid'
       GROUP BY DATE(created_at) ORDER BY date`
    );

    res.json({
      success: true,
      data: {
        stats: {
          orders: ordersRes.rows[0],
          revenue: revenueRes.rows[0],
          users: usersRes.rows[0],
          cakes: cakesRes.rows[0],
        },
        recentOrders: recentRes.rows,
        ordersByStatus: statusRes.rows,
        revenueByDay: revenueByDay.rows,
      },
    });
  } catch (err) { next(err); }
};

const getUsers = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search, role } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const conditions = ['role != \'super_admin\''];
    const params = [];
    let pi = 1;

    if (search) { conditions.push(`(email ILIKE $${pi} OR first_name ILIKE $${pi} OR last_name ILIKE $${pi})`); params.push(`%${search}%`); pi++; }
    if (role)   { conditions.push(`role = $${pi++}`); params.push(role); }

    const where = `WHERE ${conditions.join(' AND ')}`;
    const countRes = await query(`SELECT COUNT(*) FROM users ${where}`, params);

    const usersRes = await query(
      `SELECT id, email, first_name, last_name, phone, role, is_active, last_login, created_at,
              (SELECT COUNT(*) FROM orders WHERE user_id = users.id)::int AS order_count
       FROM users ${where}
       ORDER BY created_at DESC LIMIT $${pi} OFFSET $${pi+1}`,
      [...params, parseInt(limit), offset]
    );

    res.json({
      success: true,
      data: { users: usersRes.rows, pagination: { total: parseInt(countRes.rows[0].count), page: parseInt(page), limit: parseInt(limit) } },
    });
  } catch (err) { next(err); }
};

const toggleUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { rows } = await query(
      'UPDATE users SET is_active = NOT is_active WHERE id = $1 AND role != \'super_admin\' RETURNING id, email, is_active',
      [id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, data: { user: rows[0] } });
  } catch (err) { next(err); }
};

module.exports = { getDashboard, getUsers, toggleUserStatus };
