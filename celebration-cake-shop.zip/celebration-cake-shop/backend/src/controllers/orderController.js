const { query } = require('../config/database');
const logger = require('../utils/logger');

const generateOrderNumber = () => `ORD-${Date.now()}-${Math.random().toString(36).substr(2,4).toUpperCase()}`;

exports.createOrder = async (req, res) => {
  try {
    const { items, delivery_address, delivery_date, delivery_time, payment_method, special_instructions } = req.body;
    const custom_cake_image = req.file ? `/uploads/${req.file.filename}` : null;

    let subtotal = 0;
    for (const item of items) {
      const cake = await query('SELECT price FROM cakes WHERE id = $1 AND is_available = true', [item.cake_id]);
      if (!cake.rows[0]) return res.status(400).json({ success: false, message: `Cake ${item.cake_id} not available` });
      subtotal += cake.rows[0].price * item.quantity;
    }
    const delivery_fee = subtotal > 100 ? 0 : 9.99;
    const total = subtotal + delivery_fee;
    const order_number = generateOrderNumber();

    const trackingUpdate = { status: 'pending', message: 'Order placed successfully', timestamp: new Date().toISOString() };

    const result = await query(
      `INSERT INTO orders (order_number,user_id,items,subtotal,delivery_fee,total,delivery_address,delivery_date,delivery_time,payment_method,special_instructions,custom_cake_image,tracking_updates)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [order_number, req.user.id, JSON.stringify(items), subtotal, delivery_fee, total,
       JSON.stringify(delivery_address), delivery_date, delivery_time,
       payment_method || 'card', special_instructions, custom_cake_image,
       JSON.stringify([trackingUpdate])]
    );
    res.status(201).json({ success: true, data: result.rows[0], message: 'Order placed successfully' });
  } catch (err) {
    logger.error('Create order error:', err);
    res.status(500).json({ success: false, message: 'Failed to create order' });
  }
};

exports.getMyOrders = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const conditions = ['user_id = $1'];
    const params = [req.user.id];
    let idx = 2;
    if (status) { conditions.push(`status = $${idx++}`); params.push(status); }
    const offset = (parseInt(page)-1)*parseInt(limit);
    const total = (await query(`SELECT COUNT(*) FROM orders WHERE ${conditions.join(' AND ')}`, params)).rows[0].count;
    params.push(parseInt(limit), offset);
    const result = await query(`SELECT * FROM orders WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC LIMIT $${idx++} OFFSET $${idx++}`, params);
    res.json({ success: true, data: result.rows, pagination: { total: parseInt(total), page: parseInt(page), limit: parseInt(limit) } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch orders' });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const result = await query('SELECT * FROM orders WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    if (!result.rows[0]) return res.status(404).json({ success: false, message: 'Order not found' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch order' });
  }
};

exports.cancelOrder = async (req, res) => {
  try {
    const result = await query('SELECT * FROM orders WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    const order = result.rows[0];
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    if (!['pending','confirmed'].includes(order.status)) {
      return res.status(400).json({ success: false, message: 'Order cannot be cancelled at this stage' });
    }
    const updates = [...(order.tracking_updates || []), { status: 'cancelled', message: 'Order cancelled by customer', timestamp: new Date().toISOString() }];
    await query('UPDATE orders SET status=$1, tracking_updates=$2 WHERE id=$3', ['cancelled', JSON.stringify(updates), req.params.id]);
    res.json({ success: true, message: 'Order cancelled successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to cancel order' });
  }
};

// Admin
exports.getAllOrders = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const conditions = [];
    const params = [];
    let idx = 1;
    if (status) { conditions.push(`o.status = $${idx++}`); params.push(status); }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (parseInt(page)-1)*parseInt(limit);
    const total = (await query(`SELECT COUNT(*) FROM orders o ${where}`, params)).rows[0].count;
    params.push(parseInt(limit), offset);
    const result = await query(
      `SELECT o.*, u.name as customer_name, u.email as customer_email FROM orders o LEFT JOIN users u ON o.user_id = u.id ${where} ORDER BY o.created_at DESC LIMIT $${idx++} OFFSET $${idx++}`,
      params
    );
    res.json({ success: true, data: result.rows, pagination: { total: parseInt(total), page: parseInt(page), limit: parseInt(limit) } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch orders' });
  }
};

exports.updateOrderStatus = async (req, res) => {
  try {
    const { status, message } = req.body;
    const valid = ['pending','confirmed','preparing','baking','ready','out_for_delivery','delivered','cancelled'];
    if (!valid.includes(status)) return res.status(400).json({ success: false, message: 'Invalid status' });
    const result = await query('SELECT * FROM orders WHERE id = $1', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ success: false, message: 'Order not found' });
    const order = result.rows[0];
    const statusMessages = {
      confirmed: 'Your order has been confirmed', preparing: 'We are preparing your cake',
      baking: 'Your cake is now in the oven', ready: 'Your cake is ready for delivery',
      out_for_delivery: 'Your cake is on its way', delivered: 'Your cake has been delivered'
    };
    const updates = [...(order.tracking_updates || []), {
      status, message: message || statusMessages[status] || `Order ${status}`, timestamp: new Date().toISOString()
    }];
    const updated = await query('UPDATE orders SET status=$1, tracking_updates=$2 WHERE id=$3 RETURNING *', [status, JSON.stringify(updates), req.params.id]);
    res.json({ success: true, data: updated.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update order' });
  }
};

exports.getAdminStats = async (req, res) => {
  try {
    const [totalOrders, totalRevenue, totalCustomers, pendingOrders, recentOrders, topCakes] = await Promise.all([
      query('SELECT COUNT(*) FROM orders WHERE status != $1', ['cancelled']),
      query("SELECT COALESCE(SUM(total),0) as revenue FROM orders WHERE payment_status = 'paid'"),
      query("SELECT COUNT(DISTINCT id) FROM users WHERE role = 'customer'"),
      query("SELECT COUNT(*) FROM orders WHERE status IN ('pending','confirmed','preparing','baking')"),
      query('SELECT o.*, u.name as customer_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5'),
      query(`SELECT items, COUNT(*) as order_count FROM orders WHERE status != 'cancelled' GROUP BY items ORDER BY order_count DESC LIMIT 5`)
    ]);
    res.json({ success: true, data: {
      totalOrders: parseInt(totalOrders.rows[0].count),
      totalRevenue: parseFloat(totalRevenue.rows[0].revenue),
      totalCustomers: parseInt(totalCustomers.rows[0].count),
      pendingOrders: parseInt(pendingOrders.rows[0].count),
      recentOrders: recentOrders.rows
    }});
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch stats' });
  }
};
