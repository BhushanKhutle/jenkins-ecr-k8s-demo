const router = require('express').Router();
const { getAllCakes, getCakeById, getFeaturedCakes, getCategories } = require('../controllers/cakeController');

router.get('/', getAllCakes);
router.get('/featured', getFeaturedCakes);
router.get('/categories', getCategories);
router.get('/:id', getCakeById);

module.exports = router;
