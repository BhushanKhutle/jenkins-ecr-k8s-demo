const express = require('express');
const { authenticate } = require('../middleware/auth');
const { query } = require('../config/database');
const router = express.Router();

router.get('/cake/:cakeId', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT r.*, u.first_name, u.last_name, u.avatar_url
       FROM reviews r JOIN users u ON u.id = r.user_id
       WHERE r.cake_id = $1 AND r.is_approved = TRUE
       ORDER BY r.created_at DESC`, [req.params.cakeId]
    );
    res.json({ success: true, data: { reviews: rows } });
  } catch (err) { next(err); }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const { cakeId, orderId, rating, title, content } = req.body;
    const { rows } = await query(
      `INSERT INTO reviews (cake_id, user_id, order_id, rating, title, content)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [cakeId, req.user.id, orderId, rating, title, content]
    );
    await query(
      `UPDATE cakes SET rating_avg = (SELECT AVG(rating) FROM reviews WHERE cake_id=$1),
                        rating_count = (SELECT COUNT(*) FROM reviews WHERE cake_id=$1)
       WHERE id = $1`, [cakeId]
    );
    res.status(201).json({ success: true, data: { review: rows[0] } });
  } catch (err) { next(err); }
});

module.exports = router;
