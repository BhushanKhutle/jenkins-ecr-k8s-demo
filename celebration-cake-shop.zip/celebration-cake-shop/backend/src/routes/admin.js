const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { createCake, updateCake, deleteCake, getAllCakes, getCategories } = require('../controllers/cakeController');
const { getAllOrders, updateOrderStatus, getAdminStats } = require('../controllers/orderController');
const { query } = require('../config/database');

router.use(authenticate, authorize('admin'));

router.get('/stats', getAdminStats);
router.get('/cakes', getAllCakes);
router.post('/cakes', upload.single('image'), createCake);
router.put('/cakes/:id', upload.single('image'), updateCake);
router.delete('/cakes/:id', deleteCake);
router.get('/orders', getAllOrders);
router.put('/orders/:id/status', updateOrderStatus);
router.get('/customers', async (req, res) => {
  try {
    const result = await query("SELECT id,name,email,phone,created_at,is_active FROM users WHERE role='customer' ORDER BY created_at DESC");
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch customers' });
  }
});

module.exports = router;
