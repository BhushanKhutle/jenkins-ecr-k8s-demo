const router = require('express').Router();
const { getWishlist, toggleWishlist } = require('../controllers/wishlistController');
const { authenticate } = require('../middleware/auth');

router.get('/', authenticate, getWishlist);
router.post('/toggle', authenticate, toggleWishlist);

module.exports = router;
