const express = require('express');
const router = express.Router();

router.use('/auth', require('./auth'));
router.use('/cakes', require('./cakes'));
router.use('/orders', require('./orders'));
router.use('/cart', require('./cart'));
router.use('/wishlist', require('./wishlist'));
router.use('/admin', require('./admin'));

module.exports = router;
