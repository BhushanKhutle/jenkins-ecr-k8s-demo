// categories.js
const express = require('express');
const { query } = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM categories WHERE is_active = TRUE ORDER BY sort_order');
    res.json({ success: true, data: { categories: rows } });
  } catch (err) { next(err); }
});

router.post('/', authenticate, authorize('admin','super_admin'), async (req, res, next) => {
  try {
    const { name, description, imageUrl } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const { rows } = await query(
      'INSERT INTO categories (name, slug, description, image_url) VALUES ($1,$2,$3,$4) RETURNING *',
      [name, slug, description, imageUrl]
    );
    res.status(201).json({ success: true, data: { category: rows[0] } });
  } catch (err) { next(err); }
});

module.exports = router;
