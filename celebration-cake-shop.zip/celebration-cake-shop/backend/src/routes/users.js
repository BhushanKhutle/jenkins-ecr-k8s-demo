const express = require('express');
const { authenticate } = require('../middleware/auth');
const { query } = require('../config/database');
const router = express.Router();

router.use(authenticate);

// Get profile
router.get('/profile', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT id, email, first_name, last_name, phone, avatar_url, created_at,
              (SELECT COUNT(*) FROM orders WHERE user_id = users.id)::int AS order_count
       FROM users WHERE id = $1`, [req.user.id]
    );
    res.json({ success: true, data: { user: rows[0] } });
  } catch (err) { next(err); }
});

// Update profile
router.patch('/profile', async (req, res, next) => {
  try {
    const { firstName, lastName, phone } = req.body;
    const { rows } = await query(
      'UPDATE users SET first_name=$1, last_name=$2, phone=$3 WHERE id=$4 RETURNING id, email, first_name, last_name, phone',
      [firstName, lastName, phone, req.user.id]
    );
    res.json({ success: true, data: { user: rows[0] } });
  } catch (err) { next(err); }
});

// Addresses
router.get('/addresses', async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM addresses WHERE user_id=$1 ORDER BY is_default DESC', [req.user.id]);
    res.json({ success: true, data: { addresses: rows } });
  } catch (err) { next(err); }
});

router.post('/addresses', async (req, res, next) => {
  try {
    const { label, street, city, state, postalCode, country, isDefault } = req.body;
    if (isDefault) await query('UPDATE addresses SET is_default=FALSE WHERE user_id=$1', [req.user.id]);
    const { rows } = await query(
      'INSERT INTO addresses (user_id,label,street,city,state,postal_code,country,is_default) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [req.user.id, label||'Home', street, city, state, postalCode, country||'India', isDefault||false]
    );
    res.status(201).json({ success: true, data: { address: rows[0] } });
  } catch (err) { next(err); }
});

router.delete('/addresses/:id', async (req, res, next) => {
  try {
    await query('DELETE FROM addresses WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
    res.json({ success: true, message: 'Address deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
