const rateLimit = require('express-rate-limit');

const auth = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 20,
  message: { success: false, message: 'Too many auth attempts, please try again in 15 minutes' },
  standardHeaders: true,
  legacyHeaders: false,
});

const general = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 min
  max: 200,
  message: { success: false, message: 'Too many requests, please slow down' },
  standardHeaders: true,
  legacyHeaders: false,
});

const upload = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 50,
  message: { success: false, message: 'Upload limit reached. Try again in an hour.' },
});

module.exports = { auth, general, upload };
