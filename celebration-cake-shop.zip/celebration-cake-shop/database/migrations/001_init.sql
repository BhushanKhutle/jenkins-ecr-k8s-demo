-- ============================================================
-- Celebration Cake Shop — Database Schema
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── ENUM Types ──────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('customer', 'admin', 'super_admin');
CREATE TYPE order_status AS ENUM (
  'pending', 'confirmed', 'preparing', 'baking',
  'decorating', 'quality_check', 'ready', 'out_for_delivery', 'delivered', 'cancelled'
);
CREATE TYPE payment_status AS ENUM ('pending', 'paid', 'failed', 'refunded');
CREATE TYPE cake_category AS ENUM (
  'birthday', 'wedding', 'anniversary', 'custom',
  'cupcakes', 'pastries', 'seasonal', 'vegan', 'sugar_free'
);

-- ─── Users ───────────────────────────────────────────────────
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name    VARCHAR(100) NOT NULL,
  last_name     VARCHAR(100) NOT NULL,
  phone         VARCHAR(20),
  role          user_role NOT NULL DEFAULT 'customer',
  avatar_url    TEXT,
  is_active     BOOLEAN DEFAULT TRUE,
  email_verified BOOLEAN DEFAULT FALSE,
  refresh_token TEXT,
  last_login    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Addresses ───────────────────────────────────────────────
CREATE TABLE addresses (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label       VARCHAR(50) DEFAULT 'Home',
  street      TEXT NOT NULL,
  city        VARCHAR(100) NOT NULL,
  state       VARCHAR(100) NOT NULL,
  postal_code VARCHAR(20) NOT NULL,
  country     VARCHAR(100) DEFAULT 'India',
  is_default  BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Categories ──────────────────────────────────────────────
CREATE TABLE categories (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(100) UNIQUE NOT NULL,
  slug        VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  image_url   TEXT,
  is_active   BOOLEAN DEFAULT TRUE,
  sort_order  INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Cakes (Products) ────────────────────────────────────────
CREATE TABLE cakes (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name             VARCHAR(255) NOT NULL,
  slug             VARCHAR(255) UNIQUE NOT NULL,
  description      TEXT,
  short_description VARCHAR(500),
  category_id      UUID REFERENCES categories(id),
  base_price       DECIMAL(10,2) NOT NULL,
  discount_percent INT DEFAULT 0 CHECK (discount_percent BETWEEN 0 AND 100),
  images           TEXT[] DEFAULT '{}',
  ingredients      TEXT[],
  allergens        TEXT[],
  weight_kg        DECIMAL(5,2),
  servings         INT,
  preparation_hours INT DEFAULT 24,
  is_available     BOOLEAN DEFAULT TRUE,
  is_featured      BOOLEAN DEFAULT FALSE,
  is_customizable  BOOLEAN DEFAULT FALSE,
  stock_quantity   INT DEFAULT 0,
  tags             TEXT[] DEFAULT '{}',
  rating_avg       DECIMAL(3,2) DEFAULT 0,
  rating_count     INT DEFAULT 0,
  created_by       UUID REFERENCES users(id),
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Cake Variants ───────────────────────────────────────────
CREATE TABLE cake_variants (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cake_id    UUID NOT NULL REFERENCES cakes(id) ON DELETE CASCADE,
  name       VARCHAR(100) NOT NULL,     -- e.g. "1kg", "2kg", "Half kg"
  weight_kg  DECIMAL(5,2),
  price      DECIMAL(10,2) NOT NULL,
  stock      INT DEFAULT 0,
  sku        VARCHAR(100) UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Cart ────────────────────────────────────────────────────
CREATE TABLE cart_items (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  cake_id     UUID NOT NULL REFERENCES cakes(id) ON DELETE CASCADE,
  variant_id  UUID REFERENCES cake_variants(id),
  quantity    INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
  custom_message TEXT,
  custom_image_url TEXT,
  added_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, cake_id, variant_id)
);

-- ─── Wishlist ────────────────────────────────────────────────
CREATE TABLE wishlist (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  cake_id    UUID NOT NULL REFERENCES cakes(id) ON DELETE CASCADE,
  added_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, cake_id)
);

-- ─── Orders ──────────────────────────────────────────────────
CREATE TABLE orders (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number      VARCHAR(20) UNIQUE NOT NULL,
  user_id           UUID NOT NULL REFERENCES users(id),
  address_id        UUID REFERENCES addresses(id),
  status            order_status DEFAULT 'pending',
  payment_status    payment_status DEFAULT 'pending',
  payment_method    VARCHAR(50),
  payment_reference VARCHAR(255),
  subtotal          DECIMAL(10,2) NOT NULL,
  discount_amount   DECIMAL(10,2) DEFAULT 0,
  delivery_fee      DECIMAL(10,2) DEFAULT 0,
  total_amount      DECIMAL(10,2) NOT NULL,
  special_instructions TEXT,
  delivery_date     DATE,
  delivery_time_slot VARCHAR(50),
  delivered_at      TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,
  cancel_reason     TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Order Items ─────────────────────────────────────────────
CREATE TABLE order_items (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id         UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  cake_id          UUID NOT NULL REFERENCES cakes(id),
  variant_id       UUID REFERENCES cake_variants(id),
  cake_name        VARCHAR(255) NOT NULL,
  quantity         INT NOT NULL DEFAULT 1,
  unit_price       DECIMAL(10,2) NOT NULL,
  total_price      DECIMAL(10,2) NOT NULL,
  custom_message   TEXT,
  custom_image_url TEXT
);

-- ─── Order Status History ────────────────────────────────────
CREATE TABLE order_status_history (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id    UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status      order_status NOT NULL,
  note        TEXT,
  updated_by  UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Reviews ─────────────────────────────────────────────────
CREATE TABLE reviews (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cake_id     UUID NOT NULL REFERENCES cakes(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id),
  order_id    UUID REFERENCES orders(id),
  rating      INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title       VARCHAR(255),
  content     TEXT,
  images      TEXT[] DEFAULT '{}',
  is_verified BOOLEAN DEFAULT FALSE,
  is_approved BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, cake_id, order_id)
);

-- ─── Coupons ─────────────────────────────────────────────────
CREATE TABLE coupons (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code            VARCHAR(50) UNIQUE NOT NULL,
  description     TEXT,
  discount_type   VARCHAR(20) CHECK (discount_type IN ('percent', 'fixed')),
  discount_value  DECIMAL(10,2) NOT NULL,
  min_order_value DECIMAL(10,2) DEFAULT 0,
  max_uses        INT,
  used_count      INT DEFAULT 0,
  valid_from      TIMESTAMPTZ,
  valid_until     TIMESTAMPTZ,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Notifications ───────────────────────────────────────────
CREATE TABLE notifications (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      VARCHAR(255) NOT NULL,
  message    TEXT NOT NULL,
  type       VARCHAR(50) DEFAULT 'info',
  is_read    BOOLEAN DEFAULT FALSE,
  link       TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Indexes ─────────────────────────────────────────────────
CREATE INDEX idx_cakes_category ON cakes(category_id);
CREATE INDEX idx_cakes_available ON cakes(is_available);
CREATE INDEX idx_cakes_featured ON cakes(is_featured);
CREATE INDEX idx_cakes_slug ON cakes(slug);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_number ON orders(order_number);
CREATE INDEX idx_cart_user ON cart_items(user_id);
CREATE INDEX idx_wishlist_user ON wishlist(user_id);
CREATE INDEX idx_reviews_cake ON reviews(cake_id);

-- ─── Updated At Trigger ──────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated    BEFORE UPDATE ON users    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_cakes_updated    BEFORE UPDATE ON cakes    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_orders_updated   BEFORE UPDATE ON orders   FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── Seed Data ───────────────────────────────────────────────
INSERT INTO categories (name, slug, description, sort_order) VALUES
  ('Birthday Cakes',   'birthday',   'Perfect cakes to celebrate birthdays',      1),
  ('Wedding Cakes',    'wedding',    'Elegant multi-tier wedding cakes',           2),
  ('Anniversary',      'anniversary','Romantic cakes for special milestones',      3),
  ('Custom Cakes',     'custom',     'Fully customized to your specifications',    4),
  ('Cupcakes',         'cupcakes',   'Delicious individual cupcakes',              5),
  ('Vegan',            'vegan',      'Plant-based, dairy-free options',            6),
  ('Seasonal',         'seasonal',   'Special cakes for holidays and seasons',     7);

-- Admin user (password: Admin@123)
INSERT INTO users (email, password_hash, first_name, last_name, role, is_active, email_verified)
VALUES (
  'admin@cakeshop.com',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS4Tpg6',
  'Admin', 'User', 'super_admin', TRUE, TRUE
);

-- Sample cakes
INSERT INTO cakes (name, slug, description, short_description, base_price, discount_percent, weight_kg, servings, preparation_hours, is_featured, is_available, tags) VALUES
  ('Classic Chocolate Dream',     'classic-chocolate-dream',     'Rich triple-layer chocolate cake with ganache frosting and chocolate shavings. A timeless indulgence.',          'Triple-layer chocolate perfection',    799,  10, 1.0, 8,  24, TRUE,  TRUE, ARRAY['chocolate','bestseller','classic']),
  ('Strawberry Bliss',            'strawberry-bliss',            'Light vanilla sponge layered with fresh strawberry compote and whipped cream, topped with glazed strawberries.', 'Fresh strawberry & cream delight',     649,  0,  1.0, 8,  24, TRUE,  TRUE, ARRAY['strawberry','fresh','light']),
  ('Red Velvet Romance',          'red-velvet-romance',          'Classic Southern red velvet with cream cheese frosting, perfect for romantic occasions.',                         'Velvety red layers & cream cheese',    899,  15, 1.5, 12, 36, TRUE,  TRUE, ARRAY['red-velvet','romantic','cream-cheese']),
  ('Mango Tropical Paradise',     'mango-tropical-paradise',     'Seasonal alphonso mango mousse cake on a coconut biscuit base. Pure tropical indulgence.',                       'Alphonso mango mousse masterpiece',    749,  0,  1.0, 8,  48, FALSE, TRUE, ARRAY['mango','tropical','seasonal']),
  ('Elegant White Wedding',       'elegant-white-wedding',       'Three-tier fondant-covered wedding cake with sugar flowers and ribbon details.',                                 'Timeless 3-tier wedding elegance',    3499, 0,  3.0, 30, 72, TRUE,  TRUE, ARRAY['wedding','fondant','elegant']),
  ('Rainbow Unicorn Fantasy',     'rainbow-unicorn-fantasy',     'Colorful rainbow layers with vanilla buttercream and magical unicorn decorations — kids go wild!',               'Magical rainbow layers for kids',      849,  5,  1.5, 12, 36, TRUE,  TRUE, ARRAY['kids','rainbow','unicorn','colorful']),
  ('Dark Forest Gateau',          'dark-forest-gateau',          'Traditional Black Forest: chocolate sponge, kirsch-soaked cherries, and fresh whipped cream.',                  'Classic Black Forest with cherries',   749,  0,  1.0, 8,  24, FALSE, TRUE, ARRAY['blackforest','cherry','chocolate']),
  ('Vegan Lemon Zest',            'vegan-lemon-zest',            'Zesty lemon cake made entirely from plants — no compromise on taste or texture.',                               'Bright, tangy, 100% plant-based',      699,  0,  1.0, 8,  24, FALSE, TRUE, ARRAY['vegan','lemon','plant-based']);
