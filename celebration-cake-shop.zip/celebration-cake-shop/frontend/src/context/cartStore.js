import { create } from 'zustand';
import { cartAPI, wishlistAPI } from '../services/api';
import toast from 'react-hot-toast';

const useCartStore = create((set, get) => ({
  items: [],
  wishlist: [],
  subtotal: 0,
  itemCount: 0,
  loading: false,

  fetchCart: async () => {
    try {
      const { data } = await cartAPI.get();
      set({ items: data.data.items, subtotal: data.data.subtotal, itemCount: data.data.itemCount });
    } catch {}
  },

  addToCart: async (cakeId, variantId, quantity = 1, customMessage) => {
    try {
      await cartAPI.add({ cakeId, variantId, quantity, customMessage });
      await get().fetchCart();
      toast.success('Added to cart! 🎂');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add to cart');
    }
  },

  updateItem: async (id, qty) => {
    try {
      await cartAPI.update(id, qty);
      await get().fetchCart();
    } catch {}
  },

  removeItem: async (id) => {
    try {
      await cartAPI.remove(id);
      await get().fetchCart();
      toast.success('Removed from cart');
    } catch {}
  },

  clearCart: async () => {
    try {
      await cartAPI.clear();
      set({ items: [], subtotal: 0, itemCount: 0 });
    } catch {}
  },

  fetchWishlist: async () => {
    try {
      const { data } = await wishlistAPI.get();
      set({ wishlist: data.data.items });
    } catch {}
  },

  toggleWishlist: async (cakeId) => {
    try {
      const { data } = await wishlistAPI.toggle(cakeId);
      await get().fetchWishlist();
      toast.success(data.data.wishlisted ? '❤️ Added to wishlist' : 'Removed from wishlist');
    } catch {}
  },

  isWishlisted: (cakeId) => get().wishlist.some(i => i.cake_id === cakeId),
}));

export default useCartStore;
