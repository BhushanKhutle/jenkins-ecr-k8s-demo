import React, { createContext, useContext, useState, useEffect } from 'react';
import { cartAPI } from '../services/api';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState({ items: [], total: 0 });
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const fetchCart = async () => {
    if (!user) return;
    try {
      const res = await cartAPI.get();
      setCart(res.data.data);
    } catch (err) {}
  };

  useEffect(() => { fetchCart(); }, [user]);

  const addToCart = async (cake_id, options = {}) => {
    if (!user) { toast.error('Please login to add items to cart'); return; }
    setLoading(true);
    try {
      await cartAPI.add({ cake_id, ...options });
      await fetchCart();
      toast.success('Added to cart!');
    } finally { setLoading(false); }
  };

  const updateItem = async (id, quantity) => {
    setLoading(true);
    try {
      await cartAPI.update(id, { quantity });
      await fetchCart();
    } finally { setLoading(false); }
  };

  const removeItem = async (id) => {
    try {
      await cartAPI.remove(id);
      await fetchCart();
      toast.success('Removed from cart');
    } catch (err) {}
  };

  const clearCart = async () => {
    try {
      await cartAPI.clear();
      setCart({ items: [], total: 0 });
    } catch (err) {}
  };

  return (
    <CartContext.Provider value={{ cart, loading, addToCart, updateItem, removeItem, clearCart, fetchCart, itemCount: cart.items.length }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
export default CartContext;
