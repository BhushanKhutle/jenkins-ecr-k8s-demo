import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authAPI } from '../services/api';

const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isLoading: false,

      login: async (email, password) => {
        set({ isLoading: true });
        const { data } = await authAPI.login({ email, password });
        const { user, accessToken, refreshToken } = data.data;
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', refreshToken);
        set({ user, accessToken, refreshToken, isLoading: false });
        return user;
      },

      register: async (payload) => {
        set({ isLoading: true });
        const { data } = await authAPI.register(payload);
        const { user, accessToken, refreshToken } = data.data;
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', refreshToken);
        set({ user, accessToken, refreshToken, isLoading: false });
        return user;
      },

      logout: async () => {
        try { await authAPI.logout(); } catch {}
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        set({ user: null, accessToken: null, refreshToken: null });
      },

      updateUser: (userData) => set({ user: { ...get().user, ...userData } }),

      isAuthenticated: () => !!get().user,
      isAdmin: () => ['admin', 'super_admin'].includes(get().user?.role),
    }),
    { name: 'cake-auth', partialize: (state) => ({ user: state.user }) }
  )
);

export default useAuthStore;
