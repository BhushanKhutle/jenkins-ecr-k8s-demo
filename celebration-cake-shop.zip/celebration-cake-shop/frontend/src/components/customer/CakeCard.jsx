import React from 'react';
import { Link } from 'react-router-dom';
import { HeartIcon, ShoppingCartIcon, StarIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartSolid } from '@heroicons/react/24/solid';
import useCartStore from '../../context/cartStore';
import useAuthStore from '../../context/authStore';
import { useNavigate } from 'react-router-dom';

const CAKE_EMOJIS = { birthday: '🎂', wedding: '💒', anniversary: '💕', custom: '🎨', cupcakes: '🧁', vegan: '🌿', seasonal: '❄️' };

export default function CakeCard({ cake }) {
  const user = useAuthStore((s) => s.user);
  const { addToCart, toggleWishlist, isWishlisted } = useCartStore();
  const navigate = useNavigate();
  const wishlisted = isWishlisted(cake.id);

  const discountedPrice = cake.discount_percent > 0
    ? cake.base_price * (1 - cake.discount_percent / 100)
    : null;

  const handleAddToCart = async (e) => {
    e.preventDefault();
    if (!user) return navigate('/login');
    await addToCart(cake.id);
  };

  const handleWishlist = async (e) => {
    e.preventDefault();
    if (!user) return navigate('/login');
    await toggleWishlist(cake.id);
  };

  const emoji = CAKE_EMOJIS[cake.category_slug] || '🍰';
  const imageSrc = cake.images?.[0];

  return (
    <div className="cake-card card group relative flex flex-col">
      {/* Badges */}
      <div className="absolute top-2 left-2 z-10 flex gap-1 flex-col">
        {cake.discount_percent > 0 && (
          <span className="badge bg-rose-600 text-white font-bold">{cake.discount_percent}% OFF</span>
        )}
        {cake.is_featured && (
          <span className="badge bg-amber-400 text-amber-900">⭐ Featured</span>
        )}
      </div>

      {/* Wishlist button */}
      <button onClick={handleWishlist} className="absolute top-2 right-2 z-10 p-1.5 bg-white/90 rounded-full shadow hover:shadow-md transition-all">
        {wishlisted ? <HeartSolid className="w-4 h-4 text-rose-500" /> : <HeartIcon className="w-4 h-4 text-gray-400" />}
      </button>

      {/* Image */}
      <Link to={`/cakes/${cake.slug}`} className="block overflow-hidden bg-rose-50 aspect-square">
        {imageSrc ? (
          <img src={imageSrc} alt={cake.name} className="cake-img w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-7xl select-none">{emoji}</span>
          </div>
        )}
      </Link>

      {/* Info */}
      <div className="p-4 flex flex-col flex-1">
        <Link to={`/cakes/${cake.slug}`}>
          <h3 className="font-semibold text-gray-900 line-clamp-1 hover:text-rose-600 transition-colors">{cake.name}</h3>
        </Link>

        {cake.short_description && (
          <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{cake.short_description}</p>
        )}

        {/* Rating */}
        {cake.rating_count > 0 && (
          <div className="flex items-center gap-1 mt-1.5">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <StarIcon key={i} className={`w-3 h-3 ${i < Math.round(cake.rating_avg) ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} />
              ))}
            </div>
            <span className="text-xs text-gray-500">({cake.rating_count})</span>
          </div>
        )}

        {/* Price + CTA */}
        <div className="mt-auto pt-3 flex items-center justify-between">
          <div>
            <span className="font-bold text-gray-900 text-lg">₹{Math.round(discountedPrice || cake.base_price)}</span>
            {discountedPrice && (
              <span className="text-xs text-gray-400 line-through ml-1">₹{cake.base_price}</span>
            )}
          </div>
          <button onClick={handleAddToCart} className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200">
            <ShoppingCartIcon className="w-4 h-4" />
            <span className="hidden sm:inline">Add</span>
          </button>
        </div>
      </div>
    </div>
  );
}
