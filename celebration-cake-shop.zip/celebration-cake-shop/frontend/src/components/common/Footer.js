import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🎂</span>
              <span className="font-serif text-lg font-bold text-rose-400">Celebration Cake Shop</span>
            </div>
            <p className="text-gray-400 text-sm">Handcrafted cakes for every occasion. Made with love and the finest ingredients.</p>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link to="/cakes" className="hover:text-rose-400 transition-colors">Our Cakes</Link></li>
              <li><Link to="/orders" className="hover:text-rose-400 transition-colors">Track Order</Link></li>
              <li><Link to="/register" className="hover:text-rose-400 transition-colors">Create Account</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>📍 123 Bakery Lane, Sweet City</li>
              <li>📞 +1 (555) 123-4567</li>
              <li>✉️ hello@celebrationcakes.com</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-4">Hours</h3>
            <ul className="space-y-1 text-sm text-gray-400">
              <li>Mon-Fri: 8AM - 8PM</li>
              <li>Saturday: 9AM - 6PM</li>
              <li>Sunday: 10AM - 4PM</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-6 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} Celebration Cake Shop. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
