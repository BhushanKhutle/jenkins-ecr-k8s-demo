import React, { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCartIcon, HeartIcon, UserIcon, MagnifyingGlassIcon, Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import useAuthStore from '../../context/authStore';
import useCartStore from '../../context/cartStore';
import toast from 'react-hot-toast';

export default function CustomerLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const itemCount = useCartStore((s) => s.itemCount);

  const handleLogout = async () => {
    await logout();
    toast.success('See you soon! 👋');
    navigate('/');
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/cakes?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top banner */}
      <div className="bg-rose-600 text-white text-center text-sm py-2 px-4">
        🎂 Free delivery on orders above ₹999! Use code <strong>SWEET10</strong> for 10% off
      </div>

      {/* Navbar */}
      <header className="bg-white/95 backdrop-blur sticky top-0 z-50 border-b border-rose-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <span className="text-3xl">🎂</span>
              <div>
                <span className="font-display text-xl font-bold text-rose-700 leading-none block">Celebration</span>
                <span className="font-display text-xs text-rose-400 tracking-widest uppercase">Cake Shop</span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-6">
              <Link to="/cakes" className="text-gray-700 hover:text-rose-600 font-medium transition-colors">All Cakes</Link>
              <Link to="/cakes?category=birthday" className="text-gray-700 hover:text-rose-600 font-medium transition-colors">Birthday</Link>
              <Link to="/cakes?category=wedding" className="text-gray-700 hover:text-rose-600 font-medium transition-colors">Wedding</Link>
              <Link to="/cakes?category=custom" className="text-gray-700 hover:text-rose-600 font-medium transition-colors">Custom</Link>
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button onClick={() => setSearchOpen(true)} className="p-2 hover:bg-rose-50 rounded-full transition-colors">
                <MagnifyingGlassIcon className="w-5 h-5 text-gray-600" />
              </button>

              {user ? (
                <>
                  <Link to="/wishlist" className="p-2 hover:bg-rose-50 rounded-full transition-colors">
                    <HeartIcon className="w-5 h-5 text-gray-600" />
                  </Link>
                  <Link to="/cart" className="relative p-2 hover:bg-rose-50 rounded-full transition-colors">
                    <ShoppingCartIcon className="w-5 h-5 text-gray-600" />
                    {itemCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                        {itemCount > 9 ? '9+' : itemCount}
                      </span>
                    )}
                  </Link>
                  <div className="relative group">
                    <button className="flex items-center gap-1.5 pl-2 pr-3 py-1.5 hover:bg-rose-50 rounded-full transition-colors">
                      <div className="w-7 h-7 bg-rose-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-bold text-rose-700">{user.firstName?.[0]?.toUpperCase()}</span>
                      </div>
                      <span className="text-sm font-medium text-gray-700 hidden sm:block">{user.firstName}</span>
                    </button>
                    <div className="absolute right-0 mt-1 w-48 bg-white rounded-xl shadow-lg border border-rose-100 py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                      <Link to="/profile" className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-rose-50">
                        <UserIcon className="w-4 h-4" /> My Profile
                      </Link>
                      <Link to="/orders" className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-rose-50">
                        📦 My Orders
                      </Link>
                      {['admin','super_admin'].includes(user.role) && (
                        <Link to="/admin" className="flex items-center gap-2 px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 font-medium">
                          ⚙️ Admin Panel
                        </Link>
                      )}
                      <hr className="my-1 border-rose-100" />
                      <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-rose-50 w-full text-left">
                        🚪 Logout
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <Link to="/login" className="btn-ghost text-sm">Sign In</Link>
                  <Link to="/register" className="btn-primary text-sm">Sign Up</Link>
                </div>
              )}

              <button className="md:hidden p-2" onClick={() => setMobileOpen(!mobileOpen)}>
                {mobileOpen ? <XMarkIcon className="w-6 h-6" /> : <Bars3Icon className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden bg-white border-t border-rose-100 px-4 py-3 space-y-2 animate-slide-up">
            {['All Cakes|/cakes', 'Birthday Cakes|/cakes?category=birthday', 'Wedding Cakes|/cakes?category=wedding', 'Custom Cakes|/cakes?category=custom'].map(item => {
              const [label, href] = item.split('|');
              return <Link key={label} to={href} onClick={() => setMobileOpen(false)} className="block px-3 py-2 text-gray-700 hover:bg-rose-50 rounded-lg">{label}</Link>;
            })}
          </div>
        )}
      </header>

      {/* Search overlay */}
      {searchOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-start justify-center pt-20 px-4" onClick={() => setSearchOpen(false)}>
          <form onSubmit={handleSearch} onClick={e => e.stopPropagation()} className="bg-white rounded-2xl shadow-2xl w-full max-w-xl p-4 animate-slide-up">
            <div className="flex gap-3">
              <input
                autoFocus
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search for cakes..."
                className="input flex-1 text-lg"
              />
              <button type="submit" className="btn-primary">Search</button>
            </div>
          </form>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-chocolate-900 bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-3xl">🎂</span>
              <span className="font-display text-xl font-bold">Celebration Cake Shop</span>
            </div>
            <p className="text-gray-400 text-sm">Handcrafted cakes made with love for every special moment.</p>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Shop</h4>
            <div className="space-y-2 text-sm text-gray-400">
              {['All Cakes', 'Birthday Cakes', 'Wedding Cakes', 'Custom Orders'].map(l => (
                <div key={l}><Link to="/cakes" className="hover:text-rose-300 transition-colors">{l}</Link></div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Support</h4>
            <div className="space-y-2 text-sm text-gray-400">
              {['FAQ', 'Delivery Info', 'Returns', 'Contact Us'].map(l => (
                <div key={l}><span className="hover:text-rose-300 cursor-pointer transition-colors">{l}</span></div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Contact</h4>
            <div className="space-y-2 text-sm text-gray-400">
              <p>📞 +91 98765 43210</p>
              <p>✉️ hello@cakeshop.com</p>
              <p>📍 Mumbai, Maharashtra</p>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 py-4 text-center text-sm text-gray-500">
          © 2024 Celebration Cake Shop. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
