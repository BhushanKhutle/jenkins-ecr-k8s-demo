import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { wishlistAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const PLACEHOLDER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300' viewBox='0 0 400 300'%3E%3Crect fill='%23fce7f3' width='400' height='300'/%3E%3Ctext fill='%23f43f5e' font-size='80' text-anchor='middle' x='200' y='180'%3E%F0%9F%8E%82%3C/text%3E%3C/svg%3E";

export default function CakeCard({ cake, onWishlistChange }) {
  const { addToCart } = useCart();
  const { user } = useAuth();

  const handleWishlist = async (e) => {
    e.preventDefault();
    if (!user) { toast.error('Login to add to wishlist'); return; }
    try {
      const res = await wishlistAPI.toggle(cake.id);
      toast.success(res.data.message);
      if (onWishlistChange) onWishlistChange(cake.id);
    } catch (err) {}
  };

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 group border border-gray-100 animate-fade-in">
      <div className="relative overflow-hidden">
        <Link to={`/cakes/${cake.id}`}>
          <img
            src={cake.image ? `${process.env.REACT_APP_API_URL?.replace('/api','')}${cake.image}` : PLACEHOLDER}
            alt={cake.name}
            className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500"
            onError={(e) => { e.target.src = PLACEHOLDER; }}
          />
        </Link>
        {cake.is_featured && (
          <span className="absolute top-3 left-3 bg-amber-400 text-amber-900 text-xs font-bold px-2 py-1 rounded-full">⭐ Featured</span>
        )}
        <button onClick={handleWishlist} className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm hover:scale-110 transition-transform">
          ❤️
        </button>
      </div>
      <div className="p-4">
        <div className="text-xs text-rose-500 font-medium mb-1 uppercase tracking-wide">{cake.category_name}</div>
        <Link to={`/cakes/${cake.id}`}>
          <h3 className="font-serif font-semibold text-gray-800 text-lg mb-1 hover:text-rose-600 transition-colors leading-tight">{cake.name}</h3>
        </Link>
        <p className="text-gray-500 text-sm mb-3 line-clamp-2">{cake.description}</p>
        <div className="flex items-center gap-1 mb-3">
          <span className="text-amber-400">★</span>
          <span className="text-sm font-medium text-gray-700">{Number(cake.rating).toFixed(1)}</span>
          <span className="text-gray-400 text-xs">({cake.review_count})</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-rose-600">${Number(cake.price).toFixed(2)}</span>
          <button
            onClick={() => addToCart(cake.id)}
            className="bg-rose-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-rose-700 active:scale-95 transition-all"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
