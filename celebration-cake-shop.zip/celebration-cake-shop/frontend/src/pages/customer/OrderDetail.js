import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import { orderAPI } from '../../services/api';
import toast from 'react-hot-toast';

const STATUS_STEPS = ['pending','confirmed','preparing','baking','ready','out_for_delivery','delivered'];
const STATUS_COLORS = { pending: 'bg-yellow-100 text-yellow-800', confirmed: 'bg-blue-100 text-blue-800', preparing: 'bg-purple-100 text-purple-800', baking: 'bg-orange-100 text-orange-800', ready: 'bg-green-100 text-green-800', out_for_delivery: 'bg-indigo-100 text-indigo-800', delivered: 'bg-green-100 text-green-800', cancelled: 'bg-red-100 text-red-800' };

export default function OrderDetail() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    orderAPI.getById(id).then(r => setOrder(r.data.data));
  }, [id]);

  const handleCancel = async () => {
    if (!window.confirm('Cancel this order?')) return;
    try {
      await orderAPI.cancel(id);
      toast.success('Order cancelled');
      navigate('/orders');
    } catch (err) {}
  };

  if (!order) return <div className="min-h-screen flex items-center justify-center"><div className="text-4xl animate-bounce">🎂</div></div>;

  const items = typeof order.items === 'string' ? JSON.parse(order.items) : order.items;
  const tracking = typeof order.tracking_updates === 'string' ? JSON.parse(order.tracking_updates) : (order.tracking_updates || []);
  const address = typeof order.delivery_address === 'string' ? JSON.parse(order.delivery_address) : order.delivery_address;
  const currentStep = STATUS_STEPS.indexOf(order.status);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-serif text-3xl font-bold text-gray-800">{order.order_number}</h1>
            <p className="text-gray-500 mt-1">{new Date(order.created_at).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
          <span className={`px-4 py-2 rounded-full text-sm font-semibold ${STATUS_COLORS[order.status]}`}>
            {order.status.replace(/_/g, ' ').toUpperCase()}
          </span>
        </div>

        {/* Tracking */}
        {order.status !== 'cancelled' && (
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-6">
            <h2 className="font-semibold text-gray-800 mb-5">Order Tracking</h2>
            <div className="flex items-center justify-between overflow-x-auto pb-2">
              {STATUS_STEPS.slice(0, -1).map((step, i) => (
                <div key={step} className="flex items-center">
                  <div className={`flex flex-col items-center ${i <= currentStep ? 'text-rose-600' : 'text-gray-300'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 ${i <= currentStep ? 'border-rose-500 bg-rose-50' : 'border-gray-200'}`}>
                      {i < currentStep ? '✓' : i+1}
                    </div>
                    <span className="text-xs mt-1 capitalize whitespace-nowrap">{step.replace(/_/g,' ')}</span>
                  </div>
                  {i < STATUS_STEPS.length - 2 && <div className={`w-8 h-0.5 mx-1 ${i < currentStep ? 'bg-rose-400' : 'bg-gray-200'}`} />}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Items */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="font-semibold text-gray-800 mb-4">Items ({items.length})</h2>
            <div className="space-y-3">
              {items.map((item, i) => (
                <div key={i} className="flex justify-between text-sm py-2 border-b border-gray-50 last:border-0">
                  <div>
                    <span className="font-medium text-gray-700">Cake x{item.quantity}</span>
                    {item.size && <span className="text-gray-400"> • {item.size}</span>}
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 mt-4 pt-4 space-y-2 text-sm">
              <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>${Number(order.subtotal).toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-600"><span>Delivery</span><span>${Number(order.delivery_fee).toFixed(2)}</span></div>
              <div className="flex justify-between font-bold text-gray-800 text-lg"><span>Total</span><span className="text-rose-600">${Number(order.total).toFixed(2)}</span></div>
            </div>
          </div>

          {/* Delivery Info */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="font-semibold text-gray-800 mb-4">Delivery Details</h2>
            {address && (
              <div className="text-sm text-gray-600 space-y-1 mb-4">
                <p>{address.street}</p>
                <p>{address.city}, {address.state} {address.zipCode}</p>
                {address.phone && <p>📞 {address.phone}</p>}
              </div>
            )}
            {order.delivery_date && <p className="text-sm text-gray-600">📅 {new Date(order.delivery_date).toLocaleDateString()}</p>}
            {order.delivery_time && <p className="text-sm text-gray-600 mt-1">🕐 {order.delivery_time}</p>}
            {order.special_instructions && (
              <div className="mt-3 p-3 bg-amber-50 rounded-xl">
                <p className="text-xs font-medium text-amber-700 mb-1">Special Instructions</p>
                <p className="text-sm text-amber-800">{order.special_instructions}</p>
              </div>
            )}
          </div>
        </div>

        {/* Timeline */}
        {tracking.length > 0 && (
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mt-6">
            <h2 className="font-semibold text-gray-800 mb-4">Updates</h2>
            <div className="space-y-3">
              {tracking.slice().reverse().map((t, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-2 h-2 rounded-full bg-rose-400 mt-2 shrink-0" />
                  <div>
                    <p className="text-sm text-gray-700">{t.message}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{new Date(t.timestamp).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {['pending','confirmed'].includes(order.status) && (
          <button onClick={handleCancel} className="mt-6 border-2 border-red-300 text-red-600 px-6 py-3 rounded-full font-medium hover:bg-red-50 transition-colors">
            Cancel Order
          </button>
        )}
      </div>
    </div>
  );
}
