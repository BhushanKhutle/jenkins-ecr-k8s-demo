import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import { useCart } from '../../context/CartContext';
import { orderAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function Checkout() {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [customImage, setCustomImage] = useState(null);
  const [form, setForm] = useState({
    street: '', city: '', state: '', zipCode: '', phone: '',
    delivery_date: '', delivery_time: 'morning',
    payment_method: 'card', special_instructions: ''
  });

  const deliveryFee = cart.total > 100 ? 0 : 9.99;
  const total = cart.total + deliveryFee;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (cart.items.length === 0) return;
    setLoading(true);
    try {
      const formData = new FormData();
      const items = cart.items.map(i => ({ cake_id: i.cake_id, quantity: i.quantity, size: i.size, flavor: i.flavor }));
      formData.append('items', JSON.stringify(items));
      formData.append('delivery_address', JSON.stringify({ street: form.street, city: form.city, state: form.state, zipCode: form.zipCode, phone: form.phone }));
      formData.append('delivery_date', form.delivery_date);
      formData.append('delivery_time', form.delivery_time);
      formData.append('payment_method', form.payment_method);
      if (form.special_instructions) formData.append('special_instructions', form.special_instructions);
      if (customImage) formData.append('custom_cake_image', customImage);
      const res = await orderAPI.create(formData);
      await clearCart();
      toast.success('Order placed successfully!');
      navigate(`/orders/${res.data.data.id}`);
    } catch (err) {
      // handled by interceptor
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="font-serif text-4xl font-bold text-gray-800 mb-8">Checkout</h1>
        <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery Address */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <h2 className="font-semibold text-gray-800 text-lg mb-5">📍 Delivery Address</h2>
              <div className="grid grid-cols-1 gap-4">
                <input required value={form.street} onChange={e => setForm({...form, street: e.target.value})}
                  className="border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                  placeholder="Street address" />
                <div className="grid grid-cols-3 gap-3">
                  <input required value={form.city} onChange={e => setForm({...form, city: e.target.value})}
                    className="border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                    placeholder="City" />
                  <input required value={form.state} onChange={e => setForm({...form, state: e.target.value})}
                    className="border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                    placeholder="State" />
                  <input required value={form.zipCode} onChange={e => setForm({...form, zipCode: e.target.value})}
                    className="border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                    placeholder="ZIP" />
                </div>
                <input required value={form.phone} onChange={e => setForm({...form, phone: e.target.value})}
                  className="border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300"
                  placeholder="Phone number" />
              </div>
            </div>

            {/* Delivery Time */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <h2 className="font-semibold text-gray-800 text-lg mb-5">📅 Delivery Schedule</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Delivery Date</label>
                  <input type="date" required value={form.delivery_date} onChange={e => setForm({...form, delivery_date: e.target.value})}
                    min={new Date(Date.now() + 24*60*60*1000).toISOString().split('T')[0]}
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Preferred Time</label>
                  <select value={form.delivery_time} onChange={e => setForm({...form, delivery_time: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300">
                    <option value="morning">Morning (8AM-12PM)</option>
                    <option value="afternoon">Afternoon (12PM-5PM)</option>
                    <option value="evening">Evening (5PM-8PM)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <h2 className="font-semibold text-gray-800 text-lg mb-5">💳 Payment Method</h2>
              <div className="grid grid-cols-3 gap-3">
                {['card', 'cash', 'upi'].map(method => (
                  <label key={method} className={`flex items-center justify-center gap-2 p-4 rounded-xl border-2 cursor-pointer transition-colors ${form.payment_method === method ? 'border-rose-500 bg-rose-50' : 'border-gray-200 hover:border-rose-300'}`}>
                    <input type="radio" name="payment" value={method} checked={form.payment_method === method} onChange={e => setForm({...form, payment_method: e.target.value})} className="hidden" />
                    <span className="text-lg">{method === 'card' ? '💳' : method === 'cash' ? '💵' : '📱'}</span>
                    <span className="text-sm font-medium capitalize">{method}</span>
                  </label>
                ))}
              </div>
              {form.payment_method === 'card' && (
                <div className="mt-4 p-4 bg-blue-50 rounded-xl text-sm text-blue-700">
                  🔒 Card payment will be processed securely at delivery (demo mode)
                </div>
              )}
            </div>

            {/* Custom Design */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
              <h2 className="font-semibold text-gray-800 text-lg mb-2">🎨 Custom Cake Design (Optional)</h2>
              <p className="text-sm text-gray-500 mb-4">Upload a reference image for custom decoration</p>
              <input type="file" accept="image/*" onChange={e => setCustomImage(e.target.files[0])}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-medium file:bg-rose-50 file:text-rose-700 hover:file:bg-rose-100" />
              <textarea value={form.special_instructions} onChange={e => setForm({...form, special_instructions: e.target.value})}
                rows={3} className="mt-4 w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300"
                placeholder="Special instructions, allergies, message on cake..." />
            </div>
          </div>

          {/* Order Summary */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 h-fit sticky top-24">
            <h2 className="font-serif text-xl font-bold text-gray-800 mb-5">Order Summary</h2>
            <div className="space-y-3 mb-5">
              {cart.items.map(item => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-gray-600 truncate pr-2">{item.name} x{item.quantity}</span>
                  <span className="font-medium shrink-0">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 pt-3 space-y-2 text-sm">
              <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>${cart.total.toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-600"><span>Delivery</span><span>{deliveryFee === 0 ? 'Free' : `$${deliveryFee.toFixed(2)}`}</span></div>
              <div className="flex justify-between font-bold text-lg text-gray-800 pt-2 border-t border-gray-100">
                <span>Total</span><span className="text-rose-600">${total.toFixed(2)}</span>
              </div>
            </div>
            <button type="submit" disabled={loading || cart.items.length === 0}
              className="w-full bg-rose-600 text-white py-4 rounded-full font-semibold mt-6 hover:bg-rose-700 disabled:opacity-60 transition-colors">
              {loading ? '⏳ Placing Order...' : `🎂 Place Order • $${total.toFixed(2)}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
