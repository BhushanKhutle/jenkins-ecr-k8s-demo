import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import Footer from '../../components/common/Footer';
import CakeCard from '../../components/common/CakeCard';
import { cakeAPI } from '../../services/api';

export default function Home() {
  const [featured, setFeatured] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([cakeAPI.getFeatured(), cakeAPI.getCategories()])
      .then(([f, c]) => { setFeatured(f.data.data); setCategories(c.data.data); })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Hero */}
      <section className="relative bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-10 left-10 text-9xl opacity-20">🎂</div>
          <div className="absolute bottom-10 right-10 text-8xl opacity-20">🎁</div>
          <div className="absolute top-1/2 left-1/4 text-6xl opacity-10">🌸</div>
        </div>
        <div className="max-w-7xl mx-auto px-4 py-24 sm:py-32 relative z-10">
          <div className="max-w-2xl">
            <span className="inline-block bg-rose-100 text-rose-700 text-sm font-medium px-4 py-1.5 rounded-full mb-6">
              🎉 Handcrafted with Love
            </span>
            <h1 className="font-serif text-5xl md:text-7xl font-bold text-gray-900 leading-tight mb-6">
              Every Cake
              <span className="text-rose-600 italic block">Tells a Story</span>
            </h1>
            <p className="text-gray-600 text-xl mb-10 leading-relaxed">
              Custom cakes for weddings, birthdays, and every celebration in between. 
              Baked fresh with premium ingredients.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/cakes" className="bg-rose-600 text-white px-8 py-4 rounded-full font-medium text-lg hover:bg-rose-700 transition-colors text-center shadow-lg shadow-rose-200">
                Browse Our Cakes
              </Link>
              <Link to="/register" className="border-2 border-rose-600 text-rose-600 px-8 py-4 rounded-full font-medium text-lg hover:bg-rose-50 transition-colors text-center">
                Order Custom Cake
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { icon: '🎂', title: 'Fresh Daily', desc: 'Baked fresh every morning' },
            { icon: '🚚', title: 'Free Delivery', desc: 'Orders over $100' },
            { icon: '✨', title: 'Custom Designs', desc: 'Your vision, our craft' },
            { icon: '⭐', title: '5-Star Rated', desc: '2000+ happy customers' },
          ].map((f, i) => (
            <div key={i} className="text-center">
              <div className="text-4xl mb-3">{f.icon}</div>
              <h3 className="font-semibold text-gray-800 mb-1">{f.title}</h3>
              <p className="text-gray-500 text-sm">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="font-serif text-4xl font-bold text-gray-800 text-center mb-12">Shop by Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {categories.map(cat => (
                <Link key={cat.id} to={`/cakes?category=${cat.name}`} className="bg-white rounded-2xl p-4 text-center hover:shadow-md transition-all hover:-translate-y-1 border border-gray-100 group">
                  <div className="text-3xl mb-2">🎂</div>
                  <div className="font-medium text-gray-800 text-sm group-hover:text-rose-600">{cat.name}</div>
                  <div className="text-xs text-gray-400 mt-1">{cat.cake_count} cakes</div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <h2 className="font-serif text-4xl font-bold text-gray-800">Featured Cakes</h2>
            <Link to="/cakes" className="text-rose-600 font-medium hover:text-rose-700 transition-colors">View all →</Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => <div key={i} className="bg-gray-100 rounded-2xl h-80 animate-pulse" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featured.map(cake => <CakeCard key={cake.id} cake={cake} />)}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-rose-600 to-pink-700">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-serif text-4xl font-bold text-white mb-4">Have a Special Order?</h2>
          <p className="text-rose-100 text-lg mb-8">Tell us your vision and we'll bring it to life. Custom cakes for weddings, corporate events, and more.</p>
          <Link to="/register" className="bg-white text-rose-600 px-8 py-4 rounded-full font-bold text-lg hover:bg-rose-50 transition-colors inline-block">
            Start Your Order
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
