import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import Footer from '../../components/common/Footer';
import { useCart } from '../../context/CartContext';

const PLACEHOLDER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Crect fill='%23fce7f3' width='100' height='100'/%3E%3Ctext fill='%23f43f5e' font-size='50' text-anchor='middle' x='50' y='70'%3E%F0%9F%8E%82%3C/text%3E%3C/svg%3E";

export default function Cart() {
  const { cart, updateItem, removeItem, clearCart } = useCart();
  const navigate = useNavigate();
  const deliveryFee = cart.total > 100 ? 0 : 9.99;
  const finalTotal = cart.total + deliveryFee;

  if (cart.items.length === 0) return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-24 text-center">
        <div className="text-8xl mb-6">🛒</div>
        <h2 className="font-serif text-3xl font-bold text-gray-700 mb-4">Your cart is empty</h2>
        <p className="text-gray-500 mb-8">Add some delicious cakes to get started!</p>
        <Link to="/cakes" className="bg-rose-600 text-white px-8 py-3 rounded-full font-medium hover:bg-rose-700 transition-colors">Browse Cakes</Link>
      </div>
      <Footer />
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="font-serif text-4xl font-bold text-gray-800 mb-8">Shopping Cart</h1>
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {cart.items.map(item => (
              <div key={item.id} className="bg-white rounded-2xl p-5 flex gap-4 shadow-sm border border-gray-100">
                <img
                  src={item.image ? `${process.env.REACT_APP_API_URL?.replace('/api','')}${item.image}` : PLACEHOLDER}
                  alt={item.name} className="w-20 h-20 rounded-xl object-cover shrink-0"
                  onError={e => e.target.src = PLACEHOLDER}
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-serif font-semibold text-gray-800 truncate">{item.name}</h3>
                  <p className="text-sm text-gray-500 mt-0.5">{item.size} • {item.flavor}</p>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-gray-200 rounded-full overflow-hidden">
                      <button onClick={() => updateItem(item.id, item.quantity - 1)} className="px-3 py-1 hover:bg-gray-100 transition-colors font-bold">-</button>
                      <span className="px-3 py-1 font-medium text-sm">{item.quantity}</span>
                      <button onClick={() => updateItem(item.id, item.quantity + 1)} className="px-3 py-1 hover:bg-gray-100 transition-colors font-bold">+</button>
                    </div>
                    <span className="font-bold text-rose-600 text-lg">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                </div>
                <button onClick={() => removeItem(item.id)} className="text-gray-400 hover:text-red-500 transition-colors self-start">✕</button>
              </div>
            ))}
            <button onClick={clearCart} className="text-sm text-gray-500 hover:text-red-500 transition-colors">Clear cart</button>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 h-fit sticky top-24">
            <h2 className="font-serif text-xl font-bold text-gray-800 mb-6">Order Summary</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>${cart.total.toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-600">
                <span>Delivery</span>
                <span>{deliveryFee === 0 ? <span className="text-green-600 font-medium">Free</span> : `$${deliveryFee.toFixed(2)}`}</span>
              </div>
              {cart.total < 100 && <p className="text-xs text-gray-400">Free delivery on orders over $100</p>}
              <div className="border-t border-gray-100 pt-3 flex justify-between font-bold text-gray-800 text-lg">
                <span>Total</span><span className="text-rose-600">${finalTotal.toFixed(2)}</span>
              </div>
            </div>
            <button onClick={() => navigate('/checkout')} className="w-full bg-rose-600 text-white py-4 rounded-full font-semibold mt-6 hover:bg-rose-700 transition-colors">
              Proceed to Checkout
            </button>
            <Link to="/cakes" className="block text-center text-sm text-gray-500 hover:text-rose-600 mt-3 transition-colors">Continue Shopping</Link>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
