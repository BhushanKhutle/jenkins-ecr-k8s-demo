import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { cakesAPI, categoriesAPI } from '../../services/api';
import CakeCard from '../../components/customer/CakeCard';

const HERO_SLIDES = [
  { title: 'Crafted with Love,', subtitle: 'Baked to Perfection', desc: 'Celebrate every milestone with our artisan cakes', cta: 'Order Your Cake', bg: 'from-rose-50 to-pink-100', emoji: '🎂' },
  { title: 'Dream Weddings', subtitle: 'Start with the Cake', desc: 'Exquisite multi-tier wedding cakes that tell your story', cta: 'Wedding Cakes', bg: 'from-amber-50 to-rose-50', emoji: '💒' },
  { title: 'Custom Creations', subtitle: 'Your Vision, Our Art', desc: 'Upload your design, we bring it to life', cta: 'Customize Now', bg: 'from-purple-50 to-pink-50', emoji: '✨' },
];

const FEATURES = [
  { icon: '🌿', title: 'Fresh Ingredients', desc: 'Only the finest local and organic ingredients' },
  { icon: '🎨', title: 'Custom Designs', desc: 'Fully personalized to your specifications' },
  { icon: '🚚', title: 'Same-Day Delivery', desc: 'Order before 2PM for same-day delivery' },
  { icon: '⭐', title: '5000+ Happy Orders', desc: 'Trusted by families across Mumbai' },
];

export default function Home() {
  const [featured, setFeatured] = useState([]);
  const [categories, setCategories] = useState([]);
  const [slide, setSlide] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([cakesAPI.getFeatured(), categoriesAPI.getAll()])
      .then(([cakesRes, catRes]) => {
        setFeatured(cakesRes.data.data.cakes);
        setCategories(catRes.data.data.categories);
      })
      .finally(() => setLoading(false));

    const t = setInterval(() => setSlide(s => (s + 1) % HERO_SLIDES.length), 4000);
    return () => clearInterval(t);
  }, []);

  const s = HERO_SLIDES[slide];

  return (
    <div>
      {/* Hero */}
      <section className={`bg-gradient-to-br ${s.bg} transition-all duration-1000`}>
        <div className="max-w-7xl mx-auto px-4 py-20 sm:py-28 flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1 animate-fade-in">
            <div className="badge bg-rose-100 text-rose-700 mb-4 px-3 py-1">✨ Artisan Bakery Since 2015</div>
            <h1 className="font-display text-5xl sm:text-6xl font-bold text-gray-900 leading-tight mb-2">
              {s.title}
            </h1>
            <h2 className="font-display text-4xl sm:text-5xl font-bold text-rose-600 mb-4">{s.subtitle}</h2>
            <p className="text-lg text-gray-600 mb-8 max-w-lg">{s.desc}</p>
            <div className="flex flex-wrap gap-3">
              <Link to="/cakes" className="btn-primary text-base px-8 py-3">{s.cta} →</Link>
              <Link to="/cakes?category=custom" className="btn-secondary text-base px-8 py-3">Customize</Link>
            </div>
          </div>
          <div className="text-[160px] sm:text-[200px] leading-none animate-bounce-in select-none">
            {s.emoji}
          </div>
        </div>
        {/* Slide dots */}
        <div className="flex justify-center gap-2 pb-6">
          {HERO_SLIDES.map((_, i) => (
            <button key={i} onClick={() => setSlide(i)}
              className={`w-2 h-2 rounded-full transition-all ${i === slide ? 'bg-rose-600 w-6' : 'bg-rose-300'}`} />
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="bg-white py-12 border-b border-rose-50">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6">
          {FEATURES.map(f => (
            <div key={f.title} className="text-center p-4">
              <div className="text-4xl mb-2">{f.icon}</div>
              <h3 className="font-semibold text-gray-900 mb-1">{f.title}</h3>
              <p className="text-sm text-gray-500">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        <h2 className="font-display text-3xl font-bold text-center mb-2">Shop by Occasion</h2>
        <p className="text-center text-gray-500 mb-10">Find the perfect cake for every celebration</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.slice(0, 6).map(cat => (
            <Link key={cat.id} to={`/cakes?category=${cat.slug}`}
              className="card p-4 text-center hover:-translate-y-1 transition-transform cursor-pointer group">
              <div className="text-4xl mb-2">
                {cat.slug === 'birthday' ? '🎂' : cat.slug === 'wedding' ? '💒' : cat.slug === 'anniversary' ? '💕' : cat.slug === 'custom' ? '🎨' : cat.slug === 'cupcakes' ? '🧁' : cat.slug === 'vegan' ? '🌿' : '🍰'}
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-rose-600 transition-colors">{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured cakes */}
      <section className="py-8 pb-20 max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl font-bold mb-1">Our Bestsellers</h2>
            <p className="text-gray-500">The cakes everyone is ordering</p>
          </div>
          <Link to="/cakes" className="btn-secondary text-sm">View All →</Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="card animate-pulse">
                <div className="bg-rose-100 h-48 w-full" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-rose-100 rounded w-3/4" />
                  <div className="h-3 bg-rose-50 rounded w-1/2" />
                  <div className="h-8 bg-rose-50 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {featured.map(cake => <CakeCard key={cake.id} cake={cake} />)}
          </div>
        )}
      </section>

      {/* CTA Banner */}
      <section className="bg-rose-600 py-16">
        <div className="max-w-3xl mx-auto text-center px-4">
          <h2 className="font-display text-4xl font-bold text-white mb-4">Want Something Unique?</h2>
          <p className="text-rose-100 text-lg mb-8">Upload your design and we'll create a one-of-a-kind cake just for you</p>
          <Link to="/cakes?category=custom" className="inline-block bg-white text-rose-600 font-semibold px-10 py-3 rounded-full hover:bg-rose-50 transition-colors shadow-lg">
            Start Your Custom Order 🎨
          </Link>
        </div>
      </section>
    </div>
  );
}
