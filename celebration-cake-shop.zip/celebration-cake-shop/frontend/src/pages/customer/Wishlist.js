import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import Footer from '../../components/common/Footer';
import { wishlistAPI } from '../../services/api';
import { useCart } from '../../context/CartContext';
import toast from 'react-hot-toast';

const PLACEHOLDER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect fill='%23fce7f3' width='400' height='300'/%3E%3Ctext fill='%23f43f5e' font-size='80' text-anchor='middle' x='200' y='180'%3E%F0%9F%8E%82%3C/text%3E%3C/svg%3E";

export default function Wishlist() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();

  const fetchWishlist = () => wishlistAPI.get().then(r => setItems(r.data.data)).finally(() => setLoading(false));
  useEffect(() => { fetchWishlist(); }, []);

  const handleRemove = async (cake_id) => {
    await wishlistAPI.toggle(cake_id);
    toast.success('Removed from wishlist');
    fetchWishlist();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="font-serif text-4xl font-bold text-gray-800 mb-8">My Wishlist ❤️</h1>
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[...Array(4)].map((_,i) => <div key={i} className="bg-gray-100 h-64 rounded-2xl animate-pulse" />)}</div>
        ) : items.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">💔</div>
            <h2 className="font-serif text-2xl font-bold text-gray-600 mb-3">Your wishlist is empty</h2>
            <Link to="/cakes" className="bg-rose-600 text-white px-6 py-3 rounded-full font-medium hover:bg-rose-700">Browse Cakes</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {items.map(item => (
              <div key={item.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 group">
                <div className="relative">
                  <Link to={`/cakes/${item.cake_id}`}>
                    <img src={item.image ? `${process.env.REACT_APP_API_URL?.replace('/api','')}${item.image}` : PLACEHOLDER}
                      alt={item.name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={e => e.target.src = PLACEHOLDER} />
                  </Link>
                  <button onClick={() => handleRemove(item.cake_id)} className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow text-rose-500 hover:bg-rose-50">✕</button>
                </div>
                <div className="p-4">
                  <Link to={`/cakes/${item.cake_id}`}><h3 className="font-serif font-semibold text-gray-800 hover:text-rose-600">{item.name}</h3></Link>
                  <div className="flex items-center justify-between mt-3">
                    <span className="font-bold text-rose-600 text-xl">${Number(item.price).toFixed(2)}</span>
                    <button onClick={() => addToCart(item.cake_id)} className="bg-rose-600 text-white px-3 py-1.5 rounded-full text-sm hover:bg-rose-700 transition-colors">Add to Cart</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
