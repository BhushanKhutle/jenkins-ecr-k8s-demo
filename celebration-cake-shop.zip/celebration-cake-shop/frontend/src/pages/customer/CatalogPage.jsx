import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FunnelIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { cakesAPI, categoriesAPI } from '../../services/api';
import CakeCard from '../../components/customer/CakeCard';

const SORT_OPTIONS = [
  { value: 'created_at:DESC', label: 'Newest First' },
  { value: 'price:ASC', label: 'Price: Low to High' },
  { value: 'price:DESC', label: 'Price: High to Low' },
  { value: 'rating:DESC', label: 'Top Rated' },
  { value: 'name:ASC', label: 'Name A-Z' },
];

export default function CatalogPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [cakes, setCakes] = useState([]);
  const [categories, setCategories] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    category: searchParams.get('category') || '',
    search: searchParams.get('search') || '',
    minPrice: '',
    maxPrice: '',
    featured: '',
    sort: 'created_at',
    order: 'DESC',
    page: 1,
  });

  useEffect(() => {
    categoriesAPI.getAll().then(r => setCategories(r.data.data.categories));
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = { ...filters };
    if (!params.category) delete params.category;
    if (!params.search) delete params.search;
    if (!params.minPrice) delete params.minPrice;
    if (!params.maxPrice) delete params.maxPrice;
    if (!params.featured) delete params.featured;

    cakesAPI.getAll(params).then(r => {
      setCakes(r.data.data.cakes);
      setPagination(r.data.data.pagination);
    }).finally(() => setLoading(false));
  }, [filters]);

  useEffect(() => {
    const cat = searchParams.get('category');
    const search = searchParams.get('search');
    if (cat) setFilters(f => ({ ...f, category: cat, page: 1 }));
    if (search) setFilters(f => ({ ...f, search, page: 1 }));
  }, [searchParams]);

  const handleSortChange = (val) => {
    const [sort, order] = val.split(':');
    setFilters(f => ({ ...f, sort, order, page: 1 }));
  };

  const clearFilters = () => {
    setFilters({ category: '', search: '', minPrice: '', maxPrice: '', featured: '', sort: 'created_at', order: 'DESC', page: 1 });
    setSearchParams({});
  };

  const activeFiltersCount = [filters.category, filters.search, filters.minPrice, filters.maxPrice].filter(Boolean).length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold">
            {filters.search ? `Results for "${filters.search}"` : filters.category ? categories.find(c => c.slug === filters.category)?.name || 'Cakes' : 'All Cakes'}
          </h1>
          <p className="text-gray-500 text-sm mt-1">{pagination.total || 0} cakes found</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-2 btn-secondary text-sm relative">
            <FunnelIcon className="w-4 h-4" />
            Filters
            {activeFiltersCount > 0 && <span className="bg-rose-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{activeFiltersCount}</span>}
          </button>
          <select
            value={`${filters.sort}:${filters.order}`}
            onChange={e => handleSortChange(e.target.value)}
            className="input py-2 text-sm w-48"
          >
            {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div className="card p-5 mb-6 animate-slide-up">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select className="input py-2 text-sm" value={filters.category} onChange={e => setFilters(f => ({ ...f, category: e.target.value, page: 1 }))}>
                <option value="">All Categories</option>
                {categories.map(c => <option key={c.id} value={c.slug}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Min Price (₹)</label>
              <input type="number" className="input py-2 text-sm" placeholder="0" value={filters.minPrice} onChange={e => setFilters(f => ({ ...f, minPrice: e.target.value, page: 1 }))} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Max Price (₹)</label>
              <input type="number" className="input py-2 text-sm" placeholder="5000" value={filters.maxPrice} onChange={e => setFilters(f => ({ ...f, maxPrice: e.target.value, page: 1 }))} />
            </div>
            <div className="flex items-end">
              <button onClick={clearFilters} className="flex items-center gap-1 text-sm text-rose-600 hover:underline">
                <XMarkIcon className="w-4 h-4" /> Clear all
              </button>
            </div>
          </div>
          {/* Category pills */}
          <div className="flex flex-wrap gap-2 mt-4">
            <button onClick={() => setFilters(f => ({ ...f, category: '', page: 1 }))} className={`badge px-3 py-1 cursor-pointer ${!filters.category ? 'bg-rose-600 text-white' : 'bg-rose-100 text-rose-700 hover:bg-rose-200'}`}>All</button>
            {categories.map(c => (
              <button key={c.id} onClick={() => setFilters(f => ({ ...f, category: c.slug, page: 1 }))} className={`badge px-3 py-1 cursor-pointer ${filters.category === c.slug ? 'bg-rose-600 text-white' : 'bg-rose-100 text-rose-700 hover:bg-rose-200'}`}>{c.name}</button>
            ))}
          </div>
        </div>
      )}

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="card animate-pulse">
              <div className="bg-rose-100 h-48" />
              <div className="p-4 space-y-2"><div className="h-4 bg-rose-100 rounded" /><div className="h-8 bg-rose-50 rounded" /></div>
            </div>
          ))}
        </div>
      ) : cakes.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-7xl mb-4">🔍</div>
          <h3 className="font-display text-2xl font-bold mb-2">No cakes found</h3>
          <p className="text-gray-500 mb-6">Try adjusting your filters or search terms</p>
          <button onClick={clearFilters} className="btn-primary">Clear Filters</button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
          {cakes.map(cake => <CakeCard key={cake.id} cake={cake} />)}
        </div>
      )}

      {/* Pagination */}
      {pagination.pages > 1 && (
        <div className="flex justify-center gap-2 mt-10">
          {[...Array(pagination.pages)].map((_, i) => (
            <button key={i} onClick={() => setFilters(f => ({ ...f, page: i + 1 }))}
              className={`w-9 h-9 rounded-full font-medium text-sm transition-all ${filters.page === i + 1 ? 'bg-rose-600 text-white' : 'bg-white border border-rose-200 text-gray-700 hover:border-rose-400'}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
