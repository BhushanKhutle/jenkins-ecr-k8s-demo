import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import Footer from '../../components/common/Footer';
import CakeCard from '../../components/common/CakeCard';
import { cakeAPI } from '../../services/api';

export default function CakeList() {
  const [cakes, setCakes] = useState([]);
  const [categories, setCategories] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();

  const filters = {
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    sort: searchParams.get('sort') || 'newest',
    page: searchParams.get('page') || '1',
  };

  useEffect(() => {
    cakeAPI.getCategories().then(r => setCategories(r.data.data));
  }, []);

  useEffect(() => {
    setLoading(true);
    cakeAPI.getAll(filters).then(r => {
      setCakes(r.data.data);
      setPagination(r.data.pagination);
    }).finally(() => setLoading(false));
  }, [searchParams.toString()]);

  const updateFilter = (key, val) => {
    const p = new URLSearchParams(searchParams);
    if (val) p.set(key, val); else p.delete(key);
    p.delete('page');
    setSearchParams(p);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="font-serif text-4xl font-bold text-gray-800 mb-8">Our Cakes</h1>
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className="lg:w-64 shrink-0">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 sticky top-24">
              <h2 className="font-semibold text-gray-800 mb-4">Filters</h2>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-600 mb-2">Search</label>
                <input value={filters.search} onChange={e => updateFilter('search', e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300"
                  placeholder="Search cakes..." />
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-600 mb-2">Category</label>
                <select value={filters.category} onChange={e => updateFilter('category', e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300">
                  <option value="">All Categories</option>
                  {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-600 mb-2">Price Range</label>
                <div className="flex gap-2">
                  <input type="number" value={filters.minPrice} onChange={e => updateFilter('minPrice', e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300"
                    placeholder="Min" />
                  <input type="number" value={filters.maxPrice} onChange={e => updateFilter('maxPrice', e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300"
                    placeholder="Max" />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-600 mb-2">Sort By</label>
                <select value={filters.sort} onChange={e => updateFilter('sort', e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300">
                  <option value="newest">Newest</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="rating">Best Rated</option>
                  <option value="name">Name A-Z</option>
                </select>
              </div>

              <button onClick={() => setSearchParams({})} className="w-full text-sm text-rose-600 hover:text-rose-700 font-medium">
                Clear All Filters
              </button>
            </div>
          </aside>

          {/* Cake Grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <p className="text-gray-500 text-sm">{pagination.total || 0} cakes found</p>
            </div>
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => <div key={i} className="bg-gray-100 rounded-2xl h-80 animate-pulse" />)}
              </div>
            ) : cakes.length === 0 ? (
              <div className="text-center py-20 text-gray-400">
                <div className="text-6xl mb-4">🎂</div>
                <p className="text-xl font-medium">No cakes found</p>
                <p className="text-sm mt-2">Try adjusting your filters</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {cakes.map(cake => <CakeCard key={cake.id} cake={cake} />)}
              </div>
            )}

            {/* Pagination */}
            {pagination.pages > 1 && (
              <div className="flex justify-center gap-2 mt-10">
                {[...Array(pagination.pages)].map((_, i) => (
                  <button key={i} onClick={() => updateFilter('page', String(i+1))}
                    className={`w-10 h-10 rounded-full text-sm font-medium transition-colors ${parseInt(filters.page) === i+1 ? 'bg-rose-600 text-white' : 'bg-white text-gray-600 hover:bg-rose-50 border border-gray-200'}`}>
                    {i+1}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
