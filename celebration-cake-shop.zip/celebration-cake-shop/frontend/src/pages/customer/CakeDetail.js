import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';
import Footer from '../../components/common/Footer';
import { cakeAPI, wishlistAPI } from '../../services/api';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const PLACEHOLDER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400'%3E%3Crect fill='%23fce7f3' width='600' height='400'/%3E%3Ctext fill='%23f43f5e' font-size='120' text-anchor='middle' x='300' y='260'%3E%F0%9F%8E%82%3C/text%3E%3C/svg%3E";

export default function CakeDetail() {
  const { id } = useParams();
  const [cake, setCake] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedFlavor, setSelectedFlavor] = useState('');
  const [qty, setQty] = useState(1);
  const { addToCart } = useCart();
  const { user } = useAuth();

  useEffect(() => {
    cakeAPI.getById(id).then(r => {
      setCake(r.data.data);
      if (r.data.data.sizes?.length) setSelectedSize(r.data.data.sizes[0]);
      if (r.data.data.flavors?.length) setSelectedFlavor(r.data.data.flavors[0]);
    }).finally(() => setLoading(false));
  }, [id]);

  const handleAddToCart = () => {
    addToCart(cake.id, { quantity: qty, size: selectedSize, flavor: selectedFlavor });
  };

  const handleWishlist = async () => {
    if (!user) { toast.error('Login to add to wishlist'); return; }
    const res = await wishlistAPI.toggle(cake.id);
    toast.success(res.data.message);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="text-4xl animate-bounce">🎂</div></div>;
  if (!cake) return <div className="min-h-screen flex items-center justify-center text-gray-500">Cake not found</div>;

  const imgSrc = cake.image ? `${process.env.REACT_APP_API_URL?.replace('/api','')}${cake.image}` : PLACEHOLDER;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <nav className="text-sm text-gray-500 mb-6">
          <Link to="/" className="hover:text-rose-600">Home</Link> / <Link to="/cakes" className="hover:text-rose-600">Cakes</Link> / <span className="text-gray-800">{cake.name}</span>
        </nav>

        <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-gray-100">
          <div className="grid md:grid-cols-2 gap-0">
            <div className="relative">
              <img src={imgSrc} alt={cake.name} className="w-full h-96 md:h-full object-cover" onError={e => e.target.src = PLACEHOLDER} />
              {cake.is_featured && <span className="absolute top-4 left-4 bg-amber-400 text-amber-900 font-bold px-3 py-1 rounded-full text-sm">⭐ Featured</span>}
            </div>

            <div className="p-8 md:p-10">
              <div className="text-rose-500 text-sm font-medium uppercase tracking-wide mb-2">{cake.category_name}</div>
              <h1 className="font-serif text-4xl font-bold text-gray-800 mb-4">{cake.name}</h1>

              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map(s => <span key={s} className={`text-lg ${s <= Math.round(cake.rating) ? 'text-amber-400' : 'text-gray-200'}`}>★</span>)}
                </div>
                <span className="text-sm text-gray-500">({cake.review_count} reviews)</span>
              </div>

              <p className="text-gray-600 text-lg leading-relaxed mb-6">{cake.description}</p>

              <div className="text-3xl font-bold text-rose-600 mb-6">${Number(cake.price).toFixed(2)}</div>

              <div className="space-y-4 mb-6">
                {cake.flavors?.length > 0 && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Flavor</label>
                    <div className="flex flex-wrap gap-2">
                      {cake.flavors.map(f => (
                        <button key={f} onClick={() => setSelectedFlavor(f)}
                          className={`px-4 py-2 rounded-full text-sm border-2 transition-colors ${selectedFlavor === f ? 'border-rose-500 bg-rose-50 text-rose-700' : 'border-gray-200 text-gray-600 hover:border-rose-300'}`}>
                          {f}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {cake.sizes?.length > 0 && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Size</label>
                    <div className="flex flex-wrap gap-2">
                      {cake.sizes.map(s => (
                        <button key={s} onClick={() => setSelectedSize(s)}
                          className={`px-4 py-2 rounded-full text-sm border-2 transition-colors ${selectedSize === s ? 'border-rose-500 bg-rose-50 text-rose-700' : 'border-gray-200 text-gray-600 hover:border-rose-300'}`}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center border-2 border-gray-200 rounded-full overflow-hidden">
                  <button onClick={() => setQty(Math.max(1, qty-1))} className="px-4 py-2 hover:bg-gray-100 font-bold text-lg transition-colors">-</button>
                  <span className="px-4 py-2 font-bold text-gray-800">{qty}</span>
                  <button onClick={() => setQty(qty+1)} className="px-4 py-2 hover:bg-gray-100 font-bold text-lg transition-colors">+</button>
                </div>
                <div className="text-gray-500 text-sm">
                  {cake.servings && `Serves ${cake.servings}`}
                  {cake.preparation_time && ` • Ready in ${cake.preparation_time}h`}
                </div>
              </div>

              <div className="flex gap-3">
                <button onClick={handleAddToCart} disabled={!cake.is_available}
                  className="flex-1 bg-rose-600 text-white py-4 rounded-full font-semibold text-lg hover:bg-rose-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-rose-200">
                  {cake.is_available ? 'Add to Cart' : 'Out of Stock'}
                </button>
                <button onClick={handleWishlist} className="w-14 h-14 rounded-full border-2 border-gray-200 flex items-center justify-center hover:border-rose-300 hover:bg-rose-50 transition-colors text-xl">
                  ❤️
                </button>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-100 grid grid-cols-2 gap-4 text-sm text-gray-500">
                {cake.weight && <div><span className="font-medium text-gray-700">Weight:</span> {cake.weight}kg</div>}
                {cake.allergens && <div className="col-span-2"><span className="font-medium text-gray-700">Allergens:</span> {cake.allergens}</div>}
              </div>
            </div>
          </div>
        </div>

        {/* Reviews */}
        {cake.reviews?.length > 0 && (
          <div className="mt-8 bg-white rounded-3xl shadow-sm p-8 border border-gray-100">
            <h2 className="font-serif text-2xl font-bold text-gray-800 mb-6">Customer Reviews</h2>
            <div className="space-y-4">
              {cake.reviews.map(r => (
                <div key={r.id} className="border-b border-gray-100 pb-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 bg-rose-100 rounded-full flex items-center justify-center text-rose-600 font-bold text-sm">
                      {r.user_name?.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-medium text-gray-800">{r.user_name}</span>
                    <div className="flex text-amber-400 text-sm">{'★'.repeat(r.rating)}</div>
                  </div>
                  <p className="text-gray-600 text-sm">{r.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
