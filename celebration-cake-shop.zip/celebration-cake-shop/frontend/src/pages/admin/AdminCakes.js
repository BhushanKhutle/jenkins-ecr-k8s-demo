import React, { useEffect, useState } from 'react';
import { adminAPI, cakeAPI } from '../../services/api';
import toast from 'react-hot-toast';

const PLACEHOLDER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect fill='%23fce7f3' width='80' height='80'/%3E%3Ctext fill='%23f43f5e' font-size='40' text-anchor='middle' x='40' y='56'%3E%F0%9F%8E%82%3C/text%3E%3C/svg%3E";

const EMPTY = { name: '', description: '', price: '', category_id: '', stock: '10', flavors: '', sizes: '', weight: '', servings: '', preparation_time: '24', ingredients: '', allergens: '', is_featured: false };

export default function AdminCakes() {
  const [cakes, setCakes] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [imageFile, setImageFile] = useState(null);
  const [saving, setSaving] = useState(false);

  const fetchCakes = () => { setLoading(true); adminAPI.getCakes().then(r => setCakes(r.data.data)).finally(() => setLoading(false)); };

  useEffect(() => {
    fetchCakes();
    cakeAPI.getCategories().then(r => setCategories(r.data.data));
  }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setImageFile(null); setShowModal(true); };
  const openEdit = (cake) => {
    setEditing(cake);
    setForm({ ...cake, flavors: Array.isArray(cake.flavors) ? cake.flavors.join(', ') : '', sizes: Array.isArray(cake.sizes) ? cake.sizes.join(', ') : '', price: cake.price.toString(), stock: cake.stock?.toString() || '10', weight: cake.weight?.toString() || '', servings: cake.servings?.toString() || '', preparation_time: cake.preparation_time?.toString() || '24' });
    setImageFile(null);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this cake?')) return;
    try { await adminAPI.deleteCake(id); toast.success('Cake deleted'); fetchCakes(); } catch (err) {}
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData();
      Object.keys(form).forEach(k => { if (k !== 'image' && form[k] !== '') fd.append(k, form[k]); });
      if (form.flavors) fd.set('flavors', JSON.stringify(form.flavors.split(',').map(s => s.trim()).filter(Boolean)));
      if (form.sizes) fd.set('sizes', JSON.stringify(form.sizes.split(',').map(s => s.trim()).filter(Boolean)));
      if (imageFile) fd.append('image', imageFile);
      if (editing) { await adminAPI.updateCake(editing.id, fd); toast.success('Cake updated!'); }
      else { await adminAPI.createCake(fd); toast.success('Cake created!'); }
      setShowModal(false);
      fetchCakes();
    } finally { setSaving(false); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-serif text-3xl font-bold text-gray-800">Cakes Inventory</h1>
        <button onClick={openCreate} className="bg-rose-600 text-white px-5 py-2.5 rounded-full font-medium hover:bg-rose-700 transition-colors">+ Add Cake</button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>{['Image','Name','Category','Price','Stock','Status','Actions'].map(h => <th key={h} className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? [...Array(5)].map((_,i) => <tr key={i}><td colSpan={7} className="px-4 py-4"><div className="h-4 bg-gray-100 rounded animate-pulse" /></td></tr>)
              : cakes.map(cake => (
                <tr key={cake.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <img src={cake.image ? `${process.env.REACT_APP_API_URL?.replace('/api','')}${cake.image}` : PLACEHOLDER}
                      alt={cake.name} className="w-12 h-12 rounded-xl object-cover" onError={e => e.target.src = PLACEHOLDER} />
                  </td>
                  <td className="px-4 py-3 font-medium text-gray-800 text-sm">{cake.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{cake.category_name || '-'}</td>
                  <td className="px-4 py-3 font-semibold text-gray-800 text-sm">${Number(cake.price).toFixed(2)}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{cake.stock}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${cake.is_available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {cake.is_available ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-4 py-3 flex gap-2">
                    <button onClick={() => openEdit(cake)} className="text-blue-600 hover:text-blue-800 text-sm font-medium">Edit</button>
                    <button onClick={() => handleDelete(cake.id)} className="text-red-500 hover:text-red-700 text-sm font-medium">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl my-4">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-serif text-xl font-bold text-gray-800">{editing ? 'Edit Cake' : 'Add New Cake'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-600 mb-1">Cake Name *</label>
                  <input required value={form.name} onChange={e => setForm({...form, name: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" placeholder="e.g. Chocolate Dream Cake" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Price ($) *</label>
                  <input required type="number" step="0.01" value={form.price} onChange={e => setForm({...form, price: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Category</label>
                  <select value={form.category_id} onChange={e => setForm({...form, category_id: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300">
                    <option value="">Select category</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Stock</label>
                  <input type="number" value={form.stock} onChange={e => setForm({...form, stock: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Prep Time (hours)</label>
                  <input type="number" value={form.preparation_time} onChange={e => setForm({...form, preparation_time: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-600 mb-1">Description</label>
                  <textarea rows={3} value={form.description} onChange={e => setForm({...form, description: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300 resize-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Flavors (comma-separated)</label>
                  <input value={form.flavors} onChange={e => setForm({...form, flavors: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" placeholder="Vanilla, Chocolate" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Sizes (comma-separated)</label>
                  <input value={form.sizes} onChange={e => setForm({...form, sizes: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" placeholder="6 inch, 8 inch, 10 inch" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">Image</label>
                  <input type="file" accept="image/*" onChange={e => setImageFile(e.target.files[0])}
                    className="block w-full text-sm text-gray-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-sm file:bg-rose-50 file:text-rose-700" />
                </div>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.is_featured} onChange={e => setForm({...form, is_featured: e.target.checked})} className="rounded" />
                    <span className="text-sm font-medium text-gray-600">Featured</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.is_available !== false} onChange={e => setForm({...form, is_available: e.target.checked})} className="rounded" />
                    <span className="text-sm font-medium text-gray-600">Available</span>
                  </label>
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="flex-1 bg-rose-600 text-white py-3 rounded-xl font-medium hover:bg-rose-700 disabled:opacity-60">
                  {saving ? 'Saving...' : (editing ? 'Update Cake' : 'Create Cake')}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 border border-gray-200 py-3 rounded-xl font-medium text-gray-600 hover:bg-gray-50">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
