import React, { useEffect, useState } from 'react';
import { adminAPI } from '../../services/api';
import toast from 'react-hot-toast';

const STATUSES = ['pending','confirmed','preparing','baking','ready','out_for_delivery','delivered','cancelled'];
const STATUS_COLORS = { pending: 'bg-yellow-100 text-yellow-800', confirmed: 'bg-blue-100 text-blue-800', preparing: 'bg-purple-100 text-purple-800', baking: 'bg-orange-100 text-orange-800', ready: 'bg-green-100 text-green-800', out_for_delivery: 'bg-indigo-100 text-indigo-800', delivered: 'bg-green-200 text-green-900', cancelled: 'bg-red-100 text-red-800' };

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('');
  const [selected, setSelected] = useState(null);
  const [newStatus, setNewStatus] = useState('');

  const fetchOrders = () => {
    setLoading(true);
    adminAPI.getOrders(filterStatus ? { status: filterStatus } : {}).then(r => setOrders(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { fetchOrders(); }, [filterStatus]);

  const handleUpdateStatus = async () => {
    if (!newStatus || !selected) return;
    try {
      await adminAPI.updateOrderStatus(selected.id, { status: newStatus });
      toast.success('Order status updated!');
      setSelected(null);
      setNewStatus('');
      fetchOrders();
    } catch (err) {}
  };

  return (
    <div>
      <h1 className="font-serif text-3xl font-bold text-gray-800 mb-6">Orders Management</h1>

      <div className="flex gap-3 mb-6 flex-wrap">
        <button onClick={() => setFilterStatus('')} className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${!filterStatus ? 'bg-gray-800 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}>All</button>
        {STATUSES.map(s => (
          <button key={s} onClick={() => setFilterStatus(s)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors capitalize ${filterStatus === s ? 'bg-gray-800 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}>
            {s.replace(/_/g,' ')}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                {['Order #','Customer','Items','Total','Status','Date','Action'].map(h => (
                  <th key={h} className="text-left text-xs font-semibold text-gray-500 uppercase px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                [...Array(5)].map((_,i) => <tr key={i}><td colSpan={7} className="px-4 py-4"><div className="h-4 bg-gray-100 rounded animate-pulse" /></td></tr>)
              ) : orders.map(order => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{order.order_number}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{order.customer_name || 'Guest'}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{(typeof order.items === 'string' ? JSON.parse(order.items) : order.items)?.length || 0}</td>
                  <td className="px-4 py-3 text-sm font-semibold">${Number(order.total).toFixed(2)}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${STATUS_COLORS[order.status]}`}>{order.status.replace(/_/g,' ')}</span></td>
                  <td className="px-4 py-3 text-sm text-gray-500">{new Date(order.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => { setSelected(order); setNewStatus(order.status); }}
                      className="text-rose-600 hover:text-rose-800 text-sm font-medium hover:underline">Update</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="font-serif text-xl font-bold text-gray-800 mb-1">Update Order Status</h3>
            <p className="text-sm text-gray-500 mb-5">{selected.order_number}</p>
            <select value={newStatus} onChange={e => setNewStatus(e.target.value)}
              className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-300 mb-4 capitalize">
              {STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
            </select>
            <div className="flex gap-3">
              <button onClick={handleUpdateStatus} className="flex-1 bg-rose-600 text-white py-3 rounded-xl font-medium hover:bg-rose-700">Update Status</button>
              <button onClick={() => setSelected(null)} className="flex-1 border border-gray-200 text-gray-600 py-3 rounded-xl font-medium hover:bg-gray-50">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
