import React, { useEffect, useState } from 'react';
import { adminAPI } from '../../services/api';

const STAT_CARDS = [
  { key: 'totalOrders', label: 'Total Orders', icon: '📦', color: 'bg-blue-50 text-blue-700' },
  { key: 'totalRevenue', label: 'Total Revenue', icon: '💰', color: 'bg-green-50 text-green-700', prefix: '$' },
  { key: 'totalCustomers', label: 'Customers', icon: '👥', color: 'bg-purple-50 text-purple-700' },
  { key: 'pendingOrders', label: 'Pending Orders', icon: '⏳', color: 'bg-amber-50 text-amber-700' },
];

const STATUS_COLORS = { pending: 'bg-yellow-100 text-yellow-800', confirmed: 'bg-blue-100 text-blue-800', preparing: 'bg-purple-100 text-purple-800', baking: 'bg-orange-100 text-orange-800', ready: 'bg-green-100 text-green-800', out_for_delivery: 'bg-indigo-100 text-indigo-800', delivered: 'bg-green-100 text-green-800', cancelled: 'bg-red-100 text-red-800' };

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.getStats().then(r => setStats(r.data.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64 text-4xl animate-bounce">🎂</div>;

  return (
    <div>
      <h1 className="font-serif text-3xl font-bold text-gray-800 mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {STAT_CARDS.map(card => (
          <div key={card.key} className={`bg-white rounded-2xl p-5 shadow-sm border border-gray-100`}>
            <div className={`w-10 h-10 rounded-xl ${card.color} flex items-center justify-center text-xl mb-3`}>{card.icon}</div>
            <div className="font-bold text-2xl text-gray-800">
              {card.prefix || ''}{card.key === 'totalRevenue' ? Number(stats?.[card.key] || 0).toFixed(2) : (stats?.[card.key] || 0)}
            </div>
            <div className="text-sm text-gray-500 mt-1">{card.label}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-800">Recent Orders</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                {['Order #', 'Customer', 'Total', 'Status', 'Date'].map(h => (
                  <th key={h} className="text-left text-xs font-semibold text-gray-500 uppercase px-6 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {(stats?.recentOrders || []).map(order => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-800">{order.order_number}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{order.customer_name || 'Guest'}</td>
                  <td className="px-6 py-4 text-sm font-semibold text-gray-800">${Number(order.total).toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${STATUS_COLORS[order.status]}`}>{order.status.replace(/_/g,' ')}</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{new Date(order.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
