import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const NAV = [
  { path: '/admin', label: 'Dashboard', icon: '📊', exact: true },
  { path: '/admin/orders', label: 'Orders', icon: '📦' },
  { path: '/admin/cakes', label: 'Cakes', icon: '🎂' },
  { path: '/admin/customers', label: 'Customers', icon: '👥' },
];

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-gray-900 flex-shrink-0 transition-all duration-300 flex flex-col`}>
        <div className="p-4 flex items-center gap-3 border-b border-gray-800">
          <span className="text-2xl">🎂</span>
          {sidebarOpen && <span className="font-serif text-white font-bold text-sm leading-tight">Celebration<br/>Cake Admin</span>}
        </div>
        <nav className="flex-1 p-3 space-y-1 mt-4">
          {NAV.map(item => {
            const active = item.exact ? location.pathname === item.path : location.pathname.startsWith(item.path);
            return (
              <Link key={item.path} to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors ${active ? 'bg-rose-600 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'}`}>
                <span className="text-xl shrink-0">{item.icon}</span>
                {sidebarOpen && <span className="font-medium text-sm">{item.label}</span>}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-gray-800">
          <Link to="/" className="flex items-center gap-3 px-3 py-2 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition-colors mb-1">
            <span className="text-xl">🏠</span>
            {sidebarOpen && <span className="text-sm font-medium">View Store</span>}
          </Link>
          <button onClick={() => { logout(); navigate('/login'); }}
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-gray-400 hover:bg-red-900 hover:text-white transition-colors w-full">
            <span className="text-xl">🚪</span>
            {sidebarOpen && <span className="text-sm font-medium">Logout</span>}
          </button>
        </div>
      </aside>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-500 hover:text-gray-800 text-xl">☰</button>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-rose-500 rounded-full flex items-center justify-center text-white text-sm font-bold">{user?.name?.charAt(0)}</div>
            <span className="text-sm font-medium text-gray-700">{user?.name}</span>
            <span className="text-xs bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full">Admin</span>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6"><Outlet /></main>
      </div>
    </div>
  );
}
