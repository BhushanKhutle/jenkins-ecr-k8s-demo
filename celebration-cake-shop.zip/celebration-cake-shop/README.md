# 🎂 Celebration Cake Shop

A production-ready three-tier web application for a cake business.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React.js + Tailwind CSS |
| Backend | Node.js + Express.js |
| Database | PostgreSQL |
| Auth | JWT + RBAC |
| Reverse Proxy | Nginx |
| Containerization | Docker + Docker Compose |
| Orchestration | Kubernetes |
| CI/CD | GitHub Actions |
| Monitoring | Prometheus + Grafana |
| Logging | Loki + Promtail |

## Quick Start

```bash
# 1. Clone and configure
cp .env.example .env
# Edit .env with your secrets

# 2. Start all services
docker-compose up -d

# 3. Seed the database (first run)
docker-compose exec backend node src/config/seed.js

# 4. Access the app
#   Store:    http://localhost
#   Admin:    http://localhost/admin
#   Grafana:  http://localhost:3001  (admin/admin123)
#   Prometheus: http://localhost:9090
```

## Default Credentials (after seed)

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@cakeshop.com | Admin@123 |
| Customer | customer@cakeshop.com | Customer@123 |

## Architecture

```
Internet → Nginx (Port 80)
            ├── /api/*    → Node.js Backend (Port 5000)
            │                    └── PostgreSQL (Port 5432)
            └── /*        → React Frontend (Port 3000)

Monitoring:
  Prometheus (9090) → scrapes Backend (/metrics) + Node Exporter (9100)
  Grafana (3001)    → visualizes Prometheus + Loki
  Loki (3100)       ← Promtail ships container logs
```

## Customer Features
- Browse, search & filter cakes
- Shopping cart & wishlist
- Place orders with delivery scheduling
- Upload custom cake images
- Real-time order tracking
- Order history
- Profile management

## Admin Features
- Dashboard with KPIs
- Cake inventory management (CRUD + image upload)
- Order management with status updates
  - Pending → Confirmed → Preparing → Baking → Ready → Out for Delivery → Delivered
- Customer management

## API Endpoints

### Auth
- `POST /api/auth/register` — Register
- `POST /api/auth/login` — Login
- `GET  /api/auth/profile` — Get profile (auth)
- `PUT  /api/auth/profile` — Update profile (auth)

### Cakes
- `GET /api/cakes` — List cakes (with filters)
- `GET /api/cakes/featured` — Featured cakes
- `GET /api/cakes/categories` — Categories
- `GET /api/cakes/:id` — Cake detail

### Orders
- `POST /api/orders` — Place order (auth)
- `GET  /api/orders` — My orders (auth)
- `GET  /api/orders/:id` — Order detail (auth)
- `PUT  /api/orders/:id/cancel` — Cancel order (auth)

### Cart
- `GET    /api/cart` — Get cart (auth)
- `POST   /api/cart` — Add to cart (auth)
- `PUT    /api/cart/:id` — Update quantity (auth)
- `DELETE /api/cart/:id` — Remove item (auth)

### Admin (admin role required)
- `GET /api/admin/stats` — Dashboard stats
- `GET/POST/PUT/DELETE /api/admin/cakes` — Cake CRUD
- `GET /api/admin/orders` — All orders
- `PUT /api/admin/orders/:id/status` — Update status
- `GET /api/admin/customers` — Customer list

## Kubernetes Deployment

```bash
kubectl apply -f k8s/namespace.yaml
kubectl create secret generic cakeshop-secret \
  --from-literal=DB_NAME=cakeshop \
  --from-literal=DB_USER=cakeshop \
  --from-literal=DB_PASSWORD=your_password \
  --from-literal=JWT_SECRET=your_jwt_secret \
  -n cakeshop
kubectl apply -f k8s/
```

## CI/CD

GitHub Actions pipeline (`.github/workflows/ci-cd.yml`):
1. **Test** — Backend & Frontend tests
2. **Build** — Docker images pushed to GHCR
3. **Deploy** — SSH deploy to production server

Set secrets in GitHub: `DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_SSH_KEY`

## Monitoring

- **Grafana**: http://localhost:3001 — dashboards for HTTP metrics, DB connections, system resources
- **Prometheus**: http://localhost:9090 — raw metrics
- **Loki**: Centralized log aggregation from all containers

## Make Commands

```bash
make up          # Start all services
make down        # Stop all services
make build       # Rebuild images
make logs        # Follow all logs
make backend-logs # Follow backend logs
make seed        # Seed database
make db-shell    # PostgreSQL CLI
make clean       # Remove containers + volumes
```
